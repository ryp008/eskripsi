<li class="nav-item">
    <a href="?p=index" class="nav-link">
        <i class="nav-icon fa fa-dashboard"></i>
        <p>
            Dashboard
        </p>
    </a>
</li>
<!-- data dosen -->
<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-briefcase text-danger"></i>
        <p>
            Master Data
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Mahasiswa&x=mahasiswaaktif" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Mahasiswa Aktif</p>
            </a>
        </li>
    </ul>
</li>
<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-wpforms text-danger"></i>
        <p>
            Pembayaran
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Pembayaran&x=bayar" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Form Pembayaran</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Pembayaran&x=allpembayaran" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Semua Pembayaran</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Pembayaran&x=pembayaranlunas" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Pembayaran Lunas</p>
            </a>
        </li>
    </ul>
</li>
<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-tv text-danger"></i>
        <p>
            Seminar
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Seminar&x=SeminarProposal" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Seminar Proposal</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Seminar&x=PendaftaranSempro" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Pendaftaran Seminar Proposal</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Seminar&x=SeminarHasil" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Seminar Hasil</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Seminar&x=PendaftaranSemha" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Pendaftaran Seminar Hasil</p>
            </a>
        </li>
    </ul>
</li>

<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-tv text-danger"></i>
        <p>
            Sidang
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Sidang" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Sidang Meja Hijau</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Sidang&x=PendaftaranSidang" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Pendaftaran Sidang</p>
            </a>
        </li>
    </ul>
</li>

<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-file-text text-danger"></i>
        <p>
            Laporan
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Laporan&x=LaporanPembayaran" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Laporan Pembayaran</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Laporan&x=LaporanSempro" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Laporan Seminar Proposal</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Laporan&x=LaporanSemha" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Laporan Seminar Hasil</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Laporan&x=LaporanSidang" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Laporan Sidang</p>
            </a>
        </li>
    </ul>
</li>
<li class="nav-item">
    <a href="?p=User&x=ProfilBiro" class="nav-link">
        <i class="nav-icon fa fa-gears text-danger"></i>
        <p>
            Edit Profil
        </p>
    </a>
</li>