<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <a href="?p=Tahun&x=tambahtahun" class="btn btn-info btn-flat"><i class="fa fa-calendar-plus-o"></i> Tambah Tahun</a><br/><br/>
              <table class="table table-bordered table-striped table-sm" id="dtskripsi">
                <thead>
                  <tr>
                    <th><center>No.</center></th>
                    <th><center>Kode</center></th>
                    <th><center>Tahun Akademik</center></th>
                    <th><center>Status</center></th>
                    <th><center>Keterangan</center></th>
                    <th><center><i class="fa fa-bars"></i></center></th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  $no=0;
                  foreach ($data['tahun'] as $key) { ?>
                    <tr>
                      <td><?= ++$no;?></td>
                      <td><?= $key['kode'];?></td>
                      <td><?= $key['tahun'];?></td>
                      <td><?= $key['aktif'] == 'Y' ? 'Aktif' : 'Tidak Aktif';?></td>
                      <td><?= $key['ket'];?></td>
                      <td align="center">
                        <a href="?p=Tahun&x=edittahun&id=<?= $key['id_ta'];?>" class="btn btn-info btn-sm btn-flat"><i class="fa fa-pencil"></i></a>
                        <a href="?p=Tahun&x=hapus&id=<?= $key['id_ta'];?>" class="btn btn-danger btn-sm btn-flat" onclick="return confirm('Apakah yakin ingin menghapus tahun skripsi ini?')"><i class="fa fa-trash"></i></a>
                      </td>
                    </tr>
                   <?php 
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
