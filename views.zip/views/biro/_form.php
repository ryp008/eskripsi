<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
        <form method="post" action="?p=Biro&x=Save">
          <fieldset class="form-group">
            <label for="nik">NIK</label>
            <input type="text" class="form-control" name="nik" id="nik" placeholder="Nomor induk pegawai" autocomplete="off" required>
            <small class="text-muted">Nomor Induk Pegawai.</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="nama">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Lengkap" autocomplete="off" required>
            <small class="text-muted">Nama Lengkap.</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="jabatan">Bagian</label>
            <input type="text" class="form-control" id="bagian" name="bagian" placeholder="bagian" autocomplete="off" required>
            <small class="text-muted">Bagian sekarang.</small>
          </fieldset>

          <button type="submit" class="btn btn-info"> <i class="fa fa-save" aria-hidden></i> Submit Data</button>
          <a href="?p=Biro" class="btn btn-warning"> <i class="fa fa-history" aria-hidden></i> Kembali</a>
        </form>
      </div>
    </div>