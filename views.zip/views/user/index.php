<div class="row">
	<div class="col-sm-12 offset-md-3 col-md-6">
		<!-- Horizontal Form -->
		<div class="card card-info">
			<div class="card-header">
				<h3 class="card-title">Sign in to start your session</h3>
			</div>
			<!-- /.card-header -->
			<!-- form start -->
			<form action="?p=User&x=Login" method="post" class="form-horizontal">
				<div class="card-body">
					<?php 
					if(!empty($data['pesan'])){ ?>
						<div class="alert alert-info alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h5><i class="icon fa fa-info"></i> Pesan</h5>
                  <?= $data['pesan'];?>
                </div>
                <?php } ?>
					<div class="form-group">
						<label for="inputEmail3" class="col-sm-12 control-label">Username</label>

						<div class="col-sm-12">
							<input type="text" name="TextUser" class="form-control" required="" placeholder="NIM/Username">
						</div>
					</div>
					<div class="form-group">
						<label for="inputPassword3" class="col-sm-12 control-label">Password</label>

						<div class="col-sm-12">
							<input type="password" name="TextPass" class="form-control" required="" placeholder="Password">
						</div>
					</div>
				</div>
				<!-- /.card-body -->
				<div class="card-footer">
					<button type="submit" name="submit" class="btn btn-info"> <i class="fa fa-lock"></i> Sign in</button>
					<a href="?p=index" class="btn btn-default float-right">Cancel</a>
				</div>
				<!-- /.card-footer -->
			</form>
		</div>
	</div>
</div>