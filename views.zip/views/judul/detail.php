<div class="row">
  <div class="col-md-12 col-xs-12">
    <h2 class="card-title"> <strong> &raquo; Detail Data <?=$_GET['p']?> Dengan Id </strong> <?=$_GET['id']?> |
      <!-- ambil data dari controller -->
      <?php

      $ctrl=new JudulController();

      //echo $ctrl->actionDosen();

      ?>

    </h2>
    <table class="table table-striped table-bordered table-hover">
      <tr>
        <td> <strong>Nim</strong> </td>
        <td> <?=$data[0]['nim']?></td>
      </tr>
      <tr>
        <td> <strong>Nama</strong> </td>
        <td> <?=$data[0]['Name']?></td>
      </tr>
      <tr>
        <td> <strong>Program Studi</strong> </td>
        <td> <?=$data[0]['judul']?></td>
      </tr>
      <tr>
        <td> <strong>Judul Skripsi</strong> </td>
        <td> <?=$data[0]['judul']?></td>
      </tr>
      <tr>
        <td> <strong>Latar Belakang</strong> </td>
        <td>
          <p class="text-justify">
            <?=$data[0]['latar']?>
          </p>

        </td>
      </tr>
      <tr>
        <td> <strong>Rumusan Masalah</strong> </td>
        <td> <?=$data[0]['rumusan']?></td>
      </tr>
      <tr>
        <td> <strong>Judul Skripsi</strong> </td>
        <td> <?=$data[0]['batasan']?></td>
      </tr>
      <tr>
        <td> <strong>Tujuan Penelitian</strong> </td>
        <td> <?=$data[0]['tujuan']?></td>
      </tr>
      <tr>
        <td> <strong>Manfaat Penelitian</strong> </td>
        <td> <?=$data[0]['manfaat']?></td>
      </tr>
      <tr>
        <td> <strong>Instansi Tempat Penelitian</strong> </td>
        <td> <?=$data[0]['instansi']?></td>
      </tr>
      <tr>
        <td> <strong>Bahasa Pemrograman</strong> </td>
        <td> <?=$data[0]['bahasa']?></td>
      </tr>
      <tr>
        <td> <strong>Status Judul</strong> </td>
        <td> <?=$data[0]['status']?></td>
      </tr>
      <tr>
        <td> <strong>Pemeriksa Judul</strong> </td>
        <td> <?=$data[0]['asesor']?></td>
      </tr>
      <tr>
        <td> <strong>Objek Penelitian</strong> </td>
        <td> <?=$data[0]['objek']?></td>
      </tr>
      <tr>
        <td> <strong>Tgl Pengajuan</strong> </td>
        <td> <?=$data[0]['tgl_pengajuan']?></td>
      </tr>
      <tr>
        <td> <strong>Tgl Pemeriksaan</strong> </td>
        <td> <?=$data[0]['tgl_periksa']?></td>
      </tr>
      <tr>
        <td> <strong>Komentar</strong> </td>
        <td> <?=$data[0]['comment']?></td>
      </tr>
    </table>
    <?php 
    if($sess->get('level') ==1 or $sess->get('level') ==2){?>
    <a href="?p=Judul&x=Update&id=<?= $data[0]['id'] ?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> Update</a>
    <a href="?p=Judul&x=Hapus&id=<?= $data[0]['id'] ?>" class="btn btn-outline-danger btn-sm"> <i class="fa fa-remove" aria-hidden></i> Remove </a>
    <?php } ?>
    <a href="" onclick="window.close()" class="btn btn-warning btn-sm"> <i class="fa fa-history" aria-hidden></i> Kembali </a>
    <hr>
  </div>
</div>
