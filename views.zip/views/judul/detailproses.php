<center>
  <section class="sheet padding-15mm">
    <div style="float: left">
      <!-- Each sheet element should have the class "sheet" -->
      <!-- "padding-**mm" is optional: you can set 10, 15, 20 or 25 -->
      <h4 class="text-center"><b>DETAIL JUDUL MAHASISWA STMIK ROYAL</b></h4>
      <hr>
      <div class="text-left">
        <table class="table table-sm" style="font-weight: bold; font-size: 10pt">
          <tr>
            <th>ID Judul</th>
            <td>:</td>
            <td><?php echo $data[0]['id'] ;?></td>
          </tr>
          <tr>
            <th>NIM</th>
            <td>:</td>
            <td><?php echo $data[0]['nim'] ;?></td>
          </tr>
                      <!--
                      <tr>
                          <th>Nama</th>
                          <td>:</td>
                          <td><?php echo $data[0]['Name'];?></td>
                      </tr>
                    -->
                    <tr>
                      <th>Program Studi</th>
                      <td>:</td>
                      <td ><?php
                      if ($data[0]['prodi'] == "SI") {
                        echo 'SISTEM INFORMASI';
                      } else {
                        echo 'SISTEM KOMPUTER';
                      }
                      ?>
                    </td>
                  </tr>
                  <tr>
                    <td>Judul</td>
                    <td>:</td>
                    <td><?php echo $data[0]['judul']; ?></td>
                  </tr>
                  <tr>
                    <td>Instansi</td>
                    <td>:</td>
                    <td><?php echo $data[0]['instansi']; ?></td>
                  </tr>
                  <tr>
                    <td>Objek Penelitian</td>
                    <td>:</td>
                    <td><?php echo $data[0]['objek']; ?></td>
                  </tr>
                  <tr>
                    <td>Bahasa Pemrograman</td>
                    <td>:</td>
                    <td><?php echo $data[0]['bahasa']; ?></td>
                  </tr>
                  <tr>
                    <td>Status Judul</td>
                    <td>:</td>
                    <td style="color:red;"><?php echo $data[0]['status']; ?></td>
                  </tr>
                </table>
              </div>
              <hr/>
              <!-- Judul Skripsi -->
              <center><h4><strong><?php echo $data[0]['judul']; ?></strong></h4></center><br/>
              <!-- Akhir Judul Skripsi -->

              <!-- Latar Belakang -->
              <h5 class="text-left"><strong>1.1 Latar Belakang Masalah</strong></h5><br/>
              <div class="text-justify" id="latar" style="font-size: 11pt"><?php echo $data[0]['latar']; ?></div><br/>
              <!-- Akhir Latar Belakang -->

              <!-- Rumusan Masalah -->
              <h5 class="text-left"><strong>1.2 Rumusan Masalah</strong></h5><br/>
              <div class="text-justify" id="rumusan"  style="font-size: 11pt"><?php echo $data[0]['rumusan']; ?></div><br/>
              <!-- Akhir Rumusan Masalah -->

              <!-- Batasan Masalah -->
              <h5 class="text-left"><strong>1.3 Batasan Masalah</strong></h5><br/>
              <div class="text-justify" id="batasan"  style="font-size: 11pt"><?php echo $data[0]['batasan']; ?></div><br/>
              <!-- Akhir Batasan Masalah -->

              <!-- Tujuan Penelitian -->
              <h5 class="text-left"><strong>1.4 Tujuan Penelitian</strong></h5><br/>
              <div class="text-justify" id="tujuan"  style="font-size: 11pt"><?php echo $data[0]['tujuan']; ?></div><br/>
              <!-- Akhir Tujuan Penelitian -->

              <!-- Manfaat Penelitian -->
              <h5 class="text-left"><strong>1.5 Manfaat Penelitian</strong></h5><br/>
              <div class="text-justify" id="manfaat"  style="font-size: 11pt"><?php echo $data[0]['manfaat']; ?></div><br/>
              <!-- Akhir Manfaat Penelitian -->

            </div>
          </section>
        </center>
        <?php 
        //jika prodi
        if($sess->get('level') == 2){ ?>
          <div class="container-fluid">
            <div class="card card-danger card-outline">
              <div class="card-header">
                <h3 class="card-title"><i class="fa fa-gavel"></i>  Keputusan Terhadap Judul Skripsi Mahasiswa</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <?php 
                $disabled ='';
                if($data[0]['rekomendasi'] == 'YA'){ ?>
                  <div class="alert alert-info">
                    Judul ini direkomendasikan untuk di terima sebagai judul skripsi oleh <?= $data[0]['NamaDosen'] ;?>
                  </div>
                  <div class="form-group">
                    <label>Komentar Tim Seleksi</label>
                    <textarea class="form-control" rows='3' readonly=""><?= $data[0]['comment_rekom'] ;?></textarea>
                  </div>
                  <?php }elseif($data[0]['rekomendasi'] == 'TIDAK'){ ?>
                    <div class="alert alert-danger">
                      Judul ini tidak direkomendasikan untuk di terima sebagai judul skripsi oleh <?= $data[0]['NamaDosen'] ;?>
                    </div>
                    <div class="form-group">
                      <label>Komentar Tim Seleksi</label>
                      <textarea class="form-control" rows='3' readonly=""><?= $data[0]['comment_rekom'] ;?></textarea>
                    </div>
                    <?php } ?>
                    <form class="form-horizontal" action="?p=Judul&x=ProsesDiterima" method="post">
                      <input type="hidden" name="idj" value="<?= $data[0]['id'] ;?>">
                      <input type="hidden" name="NIM" value="<?= $data[0]['NIM'] ;?>">

                      <?php  if($data[0]['rekomendasi'] == 'YA' or $data[0]['rekomendasi'] == 'TIDAK'){ ?>
                        <input type="hidden" name="act" value="proses">
                        <div class="form-group">
                          <label for="" class="col-xs-4 control-label">Keputusan Anda</label>
                          <div class="col-sm-12">
                            <select name="status" class="form-control" required="">
                              <option value="">Pilih Keputusan Terhadap Judul</option>
                              <option value="1">Judul Ini Diterima</option>
                              <option value="2">Judul Ini Ditolak</option>
                            </select>
                          </div>

                        </div>
                        <?php }else{
                          if($data[0]['rekomendasi'] == 'BELUM'){
                            $disabled ='disabled';
                            ?>
                            <div class="alert alert-danger">
                              Judul dalam proses seleksi oleh tim seleksi judul<br/>
                              Dosen : <?= $data[0]['NamaDosen']?>
                            </div>
                            <?php }else{ ?>
                              <input type="hidden" name="act" value="rekomendasikan">
                              <div class="form-group">
                                <label for="" class="col-xs-4 control-label">Rekomendasikan Ke Dosen</label>
                                <div class="col-sm-12">
                                  <select name="dosen" class="form-control" required="">
                                    <<option value="">-Pilih Dosen-</option>
                                    <?php
                                    foreach ($data2 as $row) {

            //$data['row'][0]['IDDosen2'] == $row['ID'] ? $s='selected' : $s='';
                                      echo "<option value='".$row['ID']."' $s>$row[NamaDosen]</option>";
                                    }
                                    ?>
                                  </select>
                                </div>

                              </div>
                              <?php } }?>
                              <div class="form-group">
                                <label for="" class="col-xs-4 control-label">Tulis Komentar</label>
                                <div class="col-sm-12">
                                  <textarea class="form-control" name="comment" rows="5"  placeholder="Tulis Komentar Anda Max. 200 Kata"></textarea>

                                </div>
                              </div>
                              <div class="form-group">
                                <div class="col-xs-12">
                                  <div class="alert alert-danger">
                                    Hati-hatilah dalam mengambil keputusan, proses ini hanya bisa dilakukan satu kali, jika ada masalah
                                    hubungi Administrator.
                                  </div>
                                </div>
                              </div>

                              <div class="form-group">
                                <div class="col-xs-offset-4 col-xs-8">
                                  <?php
                                  if ($data[0]['status'] == "SUDAH DITOLAK") {
                                    ?>
                                    <input type="hidden" name="kode" value="acc"/>
                                    <input id="tombol" type="submit" name="update" value="Proses Judul Mahasiswa" <?= $disabled ;?>/>
                                    <?php } else { ?>
                                      <input type="hidden" name="kode" value="acc"/>
                                      <input id="tombol" class="btn btn-info"  type="submit" name="update" value="Proses Judul Mahasiswa" <?= $disabled ;?> />
                                      <?php } ?>

                                      <br/>

                                    </div>
                                  </div>

                                </form>
                                <?php 
                                if($sess->get('level') == 1){ ?>
                                <a href="?p=Judul&x=Update&id=<?= $data[0]['id'] ?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> Update</a>
                                <a href="?p=Judul&x=Hapus&id=<?= $data[0]['id'] ?>" class="btn btn-outline-danger btn-sm"> <i class="fa fa-remove" aria-hidden></i> Remove </a>
                                <?php } ?>
                                <a href="" onclick="window.close()" class="btn btn-warning btn-sm"> <i class="fa fa-history" aria-hidden></i> Kembali </a>
                                <hr>
                              </div>
                              <!-- /.card-body -->
                            </div>
                            <!-- /.card -->

                          </div>
                          <?php }elseif($sess->get('level') == 4){ ?>
                            <div class="card card-danger card-outline">
                              <div class="card-header">
                                <h3 class="card-title"><i class="fa fa-gavel"></i>  Keputusan Terhadap Judul Skripsi Mahasiswa</h3>

                                <div class="card-tools">
                                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                  </button>
                                </div>
                                <!-- /.card-tools -->
                              </div>
                              <!-- /.card-header -->
                              <div class="card-body">
                                <?php 
                                if($data[0]['rekomendasi'] == 'YA' or $data[0]['rekomendasi'] == 'TIDAK'){ ?>
                                  <table class="table">
                                    <tr>
                                      <th>Rekomendasikan</th>
                                      <td>:</td>
                                      <td><?= $data[0]['rekomendasi'];?></td>
                                    </tr>
                                    <tr>
                                      <th>Komentar</th>
                                      <td>:</td>
                                      <td><?= $data[0]['comment_rekom'];?></td>
                                    </tr>
                                  </table>
                                  <?php 
                                }else{ ?>
                                  <form action="?p=Judul&x=ProsesRekom" method="post">
                                    <input type="hidden" name="idj" value="<?= $data[0]['id'];?>">
                                    <div class="form-group">
                                      <label>Rekomendasikan Judul</label>
                                      <select name="rekom" class="form-control col-4" required="">
                                        <option value="">-Pilih-</option>
                                        <option value="YA">Ya</option>
                                        <option value="TIDAK">Tidak</option>
                                      </select>
                                    </div>
                                    <div class="form-group">
                                      <label>Komentar</label>
                                      <textarea name="komen" class="form-control col-10" placeholder="Komentar" rows="5"></textarea>
                                    </div>
                                    <div class="form-group">
                                      <input type="submit" name="simpan" class="btn btn-info btn-flat" value="Proses Judul">
                                      <button class="btn btn-dark btn-flat" onclick="window.close()">Batal</button>
                                    </div>
                                  </form>

                                  <?php } ?>
                                </div>
                              </div>
                              <?php } ?>

