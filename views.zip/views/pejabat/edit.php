<div class="row">
  <div class="col-lg-12 col-xs-12">
    <div class="card">
      <div class="card-header">
        <h2 class="card-title"> <strong> <i class="fa fa-edit" aria-hidden></i> <b>Update Data Pejabat</b></strong> </h2>
      </div>
      <div class="card-body">
        <form method="post" action="?p=Pejabat&x=Edit">
          <input type="hidden" name="id" value="<?=$data[0]['id']?>">
          <fieldset class="form-group">
            <label for="nidn">NIDN or NIP</label>
            <input type="text" class="form-control" name="nidn" id="nidn" value="<?=$data[0]['nidn']?>" placeholder="NIDN/NIP" autocomplete="off" required>
            <small class="text-muted">Nomor Induk Dosen Nasional / Nomor Induk Pegawai.</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="nama">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?=$data[0]['nama']?>" placeholder="Nama Lengkap" autocomplete="off" required>
            <small class="text-muted">Nama Lengkap.</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="jabatan">Jabatan</label>
            <input type="text" class="form-control" id="jabatan" name="jabatan" value="<?=$data[0]['jabatan']?>" placeholder="Jabatan" autocomplete="off" required>
            <small class="text-muted">Jabatan sekarang.</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="periode">Periode Jabatan</label>
            <input type="text" class="form-control" id="periode" name="periode" value="<?=$data[0]['periode']?>" placeholder="Periode Jabatan" autocomplete="off" required>
            <small class="text-muted">Tahun periode masa jabatan.</small>
          </fieldset>

          <button type="submit" class="btn btn-info"> <i class="fa fa-edit" aria-hidden></i> Update Data</button>
          <a href="?p=Pejabat" class="btn btn-warning"> <i class="fa fa-history" aria-hidden></i> Kembali</a>
        </form>
      </div>
    </div>
  </div>
</div>
