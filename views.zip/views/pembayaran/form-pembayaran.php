<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <form method="get">
      <input type="hidden" name="p" value="Pembayaran">
      <input type="hidden" name="x" value="bayar">
      <div class="row">
        <div class="col-sm-12 col-md-1 text-right">
          <label>Cari NIM</label>
        </div>
        <div class="col-sm-12 col-md-5">
          <div class="input-group input-group-md">
            <input type="text" name="nim" class="form-control" placeholder="NIM (Nomor Induk Mahasiswa)">
            <button type="submit" class="btn btn-danger btn-flat">Go!</button>
          </span>
        </div>
      </div>
    </div>
  </form>
  <br/>
  <?php 
  if(isset($_GET['nim'])){
    if($data['mhsw']){ 
      foreach($data['mhsw'] as $key) {  ?>
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <table class="table table-sm">
              <tr>
                <th width="150px">NIM</th>
                <td width="10px">:</td>
                <td><?= $key['NIM'];?></td>
              </tr>
              <tr>
                <th>Nama</th>
                <td>:</td>
                <td><?= $key['Name'] ;?></td>
              </tr>
              <tr>
                <th>Prodi</th>
                <td>:</td>
                <td><?= $key['KodeJurusan'] == 'SI' ? 'Sistem Informasi' : 'Sistem Komputer';?></td>
              </tr>
              <tr>
                <th>Status Skripsi</th>
                <td>:</td>
                <td><?= $key['Status'] == 1 ? 'Aktif' : 'Pasif';?></td>
              </tr>
              <tr>
                <th>Status Pembayaran</th>
                <td>:</td>
                <td><?= $key['STATUS_BYR'] == 'LUNAS' ? 'Sudah Lunas' : 'Belum Lunas';?></td>
              </tr>
              <tr>
                <th>Tgl Bayar</th>
                <td>:</td>
                <td><?= $key['tgl_bayar'];?></td>
              </tr>
            </table>
            <?php 
            if($key['Status'] != 1){?>
                  <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    Mahasiswa <b> <?= $key['Name'] ;?></b> belum aktif di skripsi.
                  </div>
              <?php } ?>
            </div>
            <?php 
            if($key['STATUS_BYR'] == ''){ 
                  //jika belum lunas maka tampilkan form pembayaran 
              ?>
              <div class="col-sm-12 col-md-6">
                <div class="card">
                  <div class="card-header">
                    <h5 class="card-title">Form Pembayaran</h5>

                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-widget="collapse">
                        <i class="fa fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-tool" data-widget="remove">
                        <i class="fa fa-times"></i>
                      </button>
                    </div>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                    <form action="?p=Pembayaran&x=gobayar" method="post">
                      <div class="form-group">
                        <label for="NIM">NIM</label>
                        <input type="text" name="NIM" class="form-control" placeholder="NIM" value="<?= $key['NIM'];?>" readonly required>
                      </div>
                      <div class="form-group">
                        <label for="JenisBayar">Jenis Bayar</label>
                        <select name="JenisBayar" class="form-control" required="">
                          <option value="SKRIPSI">Bimbingan Skripsi</option>
                          <option value="KKL">Seminar KKL</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="Biaya">Besar Biaya</label>
                        <input type="hidden" name="TA" value="<?= $data['biaya'][0]['TA'];?>">
                        <input type="number" name="Biaya" class="form-control" placeholder="Besar Biaya" value="<?= $data['biaya'][0]['BIAYA'] ;?>" readonly required="">
                      </div>
                      <div class="form-group">
                        <label for="Jumlah">Jumlah Bayar</label>
                        <input type="number" name="JumlahBayar" class="form-control" placeholder="Jumlah Bayar" required="">
                      </div>
                      <!-- /.card-body -->

                      <div class="card-footer">
                        <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <?php
            }?>
          </div>
          <?php

        }
      }else{ ?>
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              Data tidak ditemukan
            </div>
          </div>
        </div>
        <?php
      }
    }
    ?>
  </div>
</div>