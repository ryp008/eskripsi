<div class="row">
    <div class="col-md-12 col-xs-12">
        <h2>
            <a href="?p=Biro&x=Tambah" class="btn btn-outline-success"><strong> <i class="fa fa-user-plus"></i> Tambah Data Biro Akademik</strong></a>
            <a href="" class="btn btn-outline-info"><strong> <i class="fa fa-user-plus"></i> Import Data Excel </strong></a>
        </h2>

        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?= $data['sub_title'];?></h5>
            </div>
            <div class="card-body">
                <table id="dtskripsi" border="0" class="table table-bordered table-sm table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Bagian</th>
                            <th width="100">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no=1;
                        for($i=0; $i<count($data['biro']); $i++) {
                        ?>
                        <tr>
                            <td><?=$no?></td>
                            <td><?=$data['biro'][$i]['nik']?></td>
                            <td><?=$data['biro'][$i]['nama']?></td>
                            <td><?=$data['biro'][$i]['bagian']?></td>
                            <td>
                                <a href="?p=Biro&x=Detail&id=<?= $data['biro'][$i]['id'] ?>" class="btn btn-outline-warning btn-sm"> <i class="fa fa-eye" aria-hidden></i> </a>
                                <a href="?p=Biro&x=Update&id=<?= $data['biro'][$i]['id'] ?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> </a>
                                <a href="?p=Biro&x=Hapus&id=<?= $data['biro'][$i]['id'] ?>" class="btn btn-outline-danger btn-sm"> <i class="fa fa-remove" onclick="return confirm('Yakin ini ingin dihapus?')" aria-hidden></i> </a>
                            </td>
                        </tr>
                        <?php $no++; } ?>
                    </tbody>
                </table>

            </div>
            <div class="card-footer">
              <i>Sumber : PDPT STMIK Royal</i>
            </div>
        </div>
    </div>
</div>
