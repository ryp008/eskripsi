<div class="card">
    <div class="card-header">
      <h5 class="card-title"><?= $data['sub_title'];?></h5>

      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-widget="collapse">
          <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
          <i class="fa fa-times"></i>
      </button>
  </div>
</div>
<!-- /.card-header -->
<div class="card-body">
    <a href="?p=ProgramStudi&x=Tambah" class="btn btn-outline-success"><strong> <i class="fa fa-plus"></i> Tambah Data ProgramStudi</strong></a>
    <a href="?p=Staff" class="btn btn-info"><strong> <i class="fa fa-users"></i> Data Staff ProgramStudi</strong></a>
    <a href="" class="btn btn-outline-info"><strong> <i class="fa fa-download"></i> Import Data Excel </strong></a>
    <br/>
    <br/>
    <table id="dtskripsi" border="0" class="table table-bordered table-sm">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Prodi</th>
                <th>Fakultas</th>
                <th>Ka. Prodi</th>
                <th>NIDN</th>
                <th width="100">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no=1;
            for($i=0; $i<count($data['prodi']); $i++) {
                ?>
                <tr>
                    <td><?=$no?></td>
                    <td><?= $data['prodi'][$i]['Kode']." - ".$data['prodi'][$i]['Prodi']?></td>
                    <td><?=$data['prodi'][$i]['Fakultas']?></td>
                    <td><?=$data['prodi'][$i]['KaProdi']?></td>
                    <td><?=$data['prodi'][$i]['NIDN']?></td>
                    <td align="center">
                       <!-- <a href="?p=ProgramStudi&x=Detail&id=<?= $data['prodi'][$i]['IDProdi'] ?>" class="btn btn-outline-warning btn-sm"> <i class="fa fa-eye" aria-hidden></i> </a> -->
                    <a href="?p=ProgramStudi&x=Update&id=<?= $data['prodi'][$i]['IDProdi'] ?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> </a>
                    <a href="?p=ProgramStudi&x=Hapus&id=<?= $data['prodi'][$i]['IDProdi'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Yakin Prodi ini dihapus?')"> <i class="fa fa-remove" aria-hidden></i> </a>
                    </td>
                </tr>
                <?php $no++; } ?>
            </tbody>
        </table>

    </div>
    <div class="card-footer">
      <i>Sumber : PDPT STMIK Royal</i>
  </div>
</div>
