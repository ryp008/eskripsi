     <div class="card">
        <div class="card-header">
          <h5 class="card-title"><?= $data['sub_title'];?></h5>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse">
              <i class="fa fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-widget="remove">
              <i class="fa fa-times"></i>
          </button>
      </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <?php 
    if(!empty($data['pesan'])){?>
<div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data['pesan'] ;?><br/>
            </div>
    <?php } ?>
    <form method="get">
      <input type="hidden" name="p" value="Pembimbing">
      <input type="hidden" name="x" value="SetPembimbing">
      <div class="row">
        <div class="col-sm-12 text-right">
          <div class="input-group input-group-md">
            <input type="text" name="cari" class="form-control" placeholder="Cari dengan NIM Atau Nama Mahasiswa">
            <span class="input-group-append">
              <button type="submit" name="go" value="filter" class="btn btn-danger btn-flat"><i class='fa fa-search'></i> <b>Cari</b></button>
              <button type="submit" name="go" value="semua" class="btn btn-info btn-flat"> <i class='fa fa-refresh'></i> <b>Semua</b></button>
            </span>
          </div>
        </div>
      </div>
    </form>
<br/>
    <div class="table-responsive">
    <table class="table table-bordered table-hover table-striped table-sm" style="font-size: 10pt">
      <thead>
        <tr>
          <th>No.</th>
          <th>NIM</th>
          <th>Name</th>
          <th>Judul Skirpsi</th>
          <th>Pembayaran</th>
          <th>Pembimbing 1</th>
          <th>Pembimbing 2</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = $data['no'];
        foreach ($data['pmb'] as $key) { ?>
          <form action="?p=Pembimbing&x=SetPembimbing&page=<?= $data['page'];?>" method="post">
            <input type="hidden" name="NIM" value="<?= $key['NIM'];?>">
            <?php
            if($key['STATUS_BYR'] =='LUNAS'){
              $type = 'submit';
              $disabled = '';
            }else{
              $type = 'button';
              $disabled = 'disabled';
            }

            if(empty($key['IDDosen1'] and $key['IDDosen2']))
              {
                $proses = 'insert';
                $tombol = 'Set';
                $btn = "btn-danger";
              }else{ ?>
            <input type="hidden" name="IDPembimbing" value="<?= $key['IDPembimbing'];?>">
            <?php
                $proses = 'update';
                $tombol = 'Update';
                $btn = "btn-info";
              }
              ?>
            <input type="hidden" name="proses" value="<?= $proses;?>">
          <tr>
            <td><?= $no ;?></td>
            <td><?= $key['NIM'];?></td>
            <td><?= $key['Name'];?></td>
            <td><?= $key['JudulSkirpsi'];?></td>
            <td><?= $key['STATUS_BYR'] == '' ? 'Belum Lunas' : $key['STATUS_BYR'];?></td>
            <td>
              <div class="input-group input-group-sm mb-3">
              <select name="IDDosen1" class="form-control input-sm" required="">
                      <option value="">-Pilih Dosen-</option>
                      <?php
                      foreach ($data['dosen'] as $row) {
                        $key['IDDosen1'] == $row['ID'] ? $s='selected' : $s='';
                        echo "<option value='".$row['ID']."' $s>$row[NamaDosen]</option>";
                      }
                      ?>
                    </select>
                  </div>
            </td>
            <td>
              <div class="input-group input-group-sm mb-3">
              <select name="IDDosen2" class="form-control input-sm" required="">
                      <option value="">-Pilih Dosen-</option>
                      <?php
                      foreach ($data['dosen'] as $row) {
                        $key['IDDosen2'] == $row['ID'] ? $s='selected' : $s='';
                        echo "<option value='".$row['ID']."' $s>$row[NamaDosen]</option>";
                      }
                      ?>
                    </select>
                  </div>
            </td>
            <td align="center">
              <input type="<?= $type ;?>" name="set" class="btn <?= $btn ;?>  btn-sm btn-flat <?= $disabled ;?>" value="<?= $tombol ;?>">
            </td>
          </tr>
        </form>
        <?php 
        $no++; 
        }
        ?>
        <tr>
          <td colspan="8">Jumlah : <?= $data['jumlah'];?></td>
        </tr>
      </tbody>
    </table>
  </div>
          <ul class="pagination">       
        <!-- LINK FIRST AND PREV -->        
        <?php if($data['page'] == 1){
         // Jika page adalah page ke 1, maka disable link PREV        
          ?>          
          <li class="page-item disabled"><a href="#" class="page-link">First</a> </li>          
          <li class="page-item disabled"><a href="#" class="page-link">&laquo;</a> </li>        
          <?php }else{ 
          // Jika page bukan page ke 1          
          $link_prev = ($data['page'] > 1)? $data['page'] - 1 : 1;?>          
          <li class="page-item"><a href="?p=Pembimbing&x=SetPembimbing&page=1" class="page-link">First</a> </li>          
          <li class="page-item"><a href="?p=Pembimbing&x=SetPembimbing&page=<?php echo $link_prev; ?>" class="page-link">&laquo;</a> </li>
        <?php
      }

      // Hitung jumlah halamannya
      $jumlah_number = 5; 
      // Tentukan jumlah link number sebelum dan sesudah page yang aktif
      $start_number = ($data['page'] > $jumlah_number)? $data['page'] - $jumlah_number : 1; 
      // Untuk awal link number
      $end_number = ($data['page'] < ($data['jumlah_page'] - $jumlah_number)) ? $data['page'] + $jumlah_number : $data['jumlah_page'];

      for($i = $start_number; $i <= $end_number; $i++){
        $link_active = ($data['page'] == $i) ? ' active ' : ''; ?>
        <li class="page-item <?php echo $link_active; ?>"><a href="?p=Pembimbing&x=SetPembimbing&page=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a></li>        
        <?php 
      }
        ?>


      <!-- LINK NEXT AND LAST -->        
      <?php        
      // Jika page sama dengan jumlah page, maka disable link NEXT nya
      // Artinya page tersebut adalah page terakhir
      if($data['page'] == $data['jumlah_page']){ 
      // Jika page terakhir ?>
      <li class="page-item disabled"><a href="#" class="page-link">&raquo;</a></li>
      <li class="page-item disabled"><a href="#" class="page-link">Last</a></li>
      <?php 
    }else{ 
    // Jika Bukan page terakhir
    $link_next = ($data['page'] < $data['jumlah_page'])? $data['page'] + 1 : $data['jumlah_page'];?>
    <li class="page-item"><a href="?p=Pembimbing&x=SetPembimbing&page=<?php echo $link_next; ?>" class="page-link">&raquo;</a></li>
    <li class="page-item"><a href="?p=Pembimbing&x=SetPembimbing&page=<?php echo $data['jumlah_page']; ?>" class="page-link">Last</a></li>
    <?php } 
    ?>
        </ul>
  </div>
  </div>
</div>