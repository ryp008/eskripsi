<div class="row">
    <div class="col-md-12 col-xs-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"> <strong> <i class="fa fa-file"></i>Judul Skripsi Sudah Ditolak</strong></h3>
                <br>
                Tampilkan Judul Skripsi : <br>
                <form action="?p=Judul&x=Ditolak" method="post">
                  <div class="input-group mb-3">
                    <select class="form-control" id="thpengajuan" name="thpengajuan">
                      <option>Pilih Tahun Pengajuan</option>
                      <?php for($i=2015; $i<= date('Y'); $i++):?>
                      <option value="<?=$i?>"><?=$i?></option>
                    <?php endfor; ?>
                    </select>
                    <div class="input-group-append">
                      <button class="btn btn-info" type="submit">Tampilkan Judul <i class="fa fa-search"></i></button>
                    </div>
                  </div>
                </form>
            </div>
            <div class="card-body">



                <table id="dtskripsi" class="table-responsive table" border="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Prodi</th>
                            <th>Judul</th>
                            <th>Bahasa</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        for ($i = 0; $i < count($data); $i++) {
                            ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td>
                                   <strong class="text-danger">  <?= $data[$i]['nim'] ?> </strong>
                                    </td>
                                <td><?= $data[$i]['prodi'] ?></td>
                                <td><?= $data[$i]['judul'] ?></td>
                                <td><?= $data[$i]['bahasa'] ?></td>
                                <td class="text-bold text-danger"><?= $data[$i]['status'] ?></td>
                                <td>
                                  <strong class="text-danger"> <i class="fa fa-remove" aria-hidden></i> </strong>
                                </td>
                            </tr>
                            <?php $no++;
                        } ?>
                    </tbody>
                </table>

            </div>
        </div>

    </div>
</div>
