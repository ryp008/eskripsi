<?php 
$ses_prodi = strtolower($sess->get('prodi'));
?>
<li class="nav-item">
                                    <a href="?p=index" class="nav-link">
                                        <i class="nav-icon fa fa-dashboard"></i>
                                        <p>
                                            Dashboard
                                        </p>
                                    </a>
                                </li>
                                <!-- data dosen -->
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-briefcase text-danger"></i>
                                        <p>
                                            Master Data
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Mahasiswa&x=mahasiswaaktif&prodi=<?= $ses_prodi ;?>" class="nav-link">
                                                <i class="fa fa-users nav-icon"></i>
                                                <p>Mahasiswa Aktif</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Dosen" class="nav-link">
                                                <i class="fa fa-users nav-icon"></i>
                                                <p>Dosen</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-book text-danger"></i>
                                        <p>
                                            Judul Skripsi
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diajukan</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&sts=proses" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diproses</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&sts=terima" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diterima</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&sts=tolak" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Ditolak</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulOffline" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Input Judul Ofline</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=GantiJudul" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Update Judul Skripsi</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                            <a href="?p=Judul&x=JudulRekomendasi" class="nav-link">
                                                <i class="fa fa-share-alt nav-icon text-danger"></i>
                                                <p>Judul Rekomendasi</p>
                                            </a>
                                        </li>
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-user text-danger"></i>
                                        <p>
                                            Pembimbing Skirpsi
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Pembimbing" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>List Pembimbing</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Pembimbing&x=SetPembimbing" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Set Pembimbing</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-television text-danger"></i>
                                        <p>
                                            Seminar dan Sidang
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Seminar&x=SeminarProposal" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Seminar Porposal</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Seminar&x=SeminarHasil" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Seminar Hasil</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Sidang" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Sidang</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>  
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-file-text-o text-danger"></i>
                                        <p>
                                            Laporan
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=Semua" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Semua Judul</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=JudulDiterima" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diterima</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=JudulDitolak" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Ditolak</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=DosenPembimbing" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Dosen Pembimbing</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item">
    <a href="?p=User&x=ProfilProdi" class="nav-link">
        <i class="nav-icon fa fa-gears text-danger"></i>
        <p>
            Edit Profil
        </p>
    </a>
</li>