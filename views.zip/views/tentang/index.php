
<div class="row">

    <div class="col-md-12 col-xs 12">
        <span class="badge badge-info"><strong style="font-size:24px;">Apa itu E-Skripsi ?</strong></span> <br>
        <p>E-Skripsi merupakan aplikasi yang digunakan untuk memanajemen proses perkuliahan riset/penelitian (skripsi) bagi mahasiswa semester akhir. Aplikasi ini sangat membantu pihak manajemen terutama program studi dalam meningkatkan pelayanan kepada mahasiswa yang telah masuk pada semester terakhir yang mengambil mata kuliah skripsi. Mata kuliah skripsi merupakan mata kuliah yang wajib di ambil oleh setiap mahasiswa yang akan menyelesaikan pendidikan sarjana di STMIK Royal Kisaran. Dengan adanya aplikasi ini diharapkan agar proses skripsi akan dapat dilaksanakan dengan mudah terutama bagi pihak program studi, biro akademik, dosen dan mahasiswa.</p>
    </div>
</div>
<!-- batas div row 1 -->

<div class="row">
    <div class="col-md-6 col-xs-12">
        <div class="card">
            <div class="card-header">
                <h2 class="card-title"> <i class="fa fa-info-circle" aria-hidden></i> Pengumuman </h2>
            </div>
            <div class="card-body">
                <blockquote cite="">
                    <p>Pelaksanaan skripsi TA. Genap 2017/2018 akan dimulai pada tanggal 10 Februari 2018. Bagi mahasiswa yang sudah melengkapi persyaratan sudah dapat mengajukan mata kuliah skripsi kepada program studi.</p>
                </blockquote>
                <blockquote>
                    <p>Peningkatan pelayanan e-skripsi maka seluruh mahasiswa yang akan mengambil mata kuliah skripsi diharapkan hadir untuk mengikuti sosialisasi penggunaan e-skripsi yang akan di laksanakan pada tanggal 12 Januari 2018. Pengumuman lengkap dapat di lihat pada <a href="#">Pengumuman Sosialisasi E-Skripsi TA. 2017/2018.</a> </p>
                </blockquote>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-xs-12">
        <div class="card bg-info">
            <div class="card-header"><strong>Download Panduan Skripsi <i class="fa fa-download" aria-hidden></i> </strong></div>
            <div class="card-body">

                <?php
                @$nama = $_SESSION['nama'];
                if (isset($nama)) {

                    echo " Nama : $nama";
                }
                ?>

                Dalam rangka meningkatkan dan menyelaraskan setiap penulisan dan aturan dalam pelaksanaan mata kuliah skripsi, maka STMIK Royal Kisaran mengeluarkan panduan skripsi untuk periode 2016-2020. Panduan ini dapat didownload pada button dibawah ini.

            </div>
            <div class="card-footer">
                <button class="btn btn-warning btn-flat"><span class="fa fa-download"></span> Skripsi Sistem Komputer</button>
                <button class="btn btn-primary btn-flat"><span class="fa fa-download"></span> Skripsi Sistem Informasi</button>
            </div>
        </div>

        <div class="alert alert-success"> Data Pengunjung <span class="badge badge-danger">4560</span></div>

    </div>
</div>
<!-- batas div row -->
<div class="row">
  <div class="col-lg-12 col-xs-12">
    <strong>Support By : </strong>
    Kementerian Riset dan Pendidikan Tinggi - Tahun Anggaran Penelitian 2018.
  </div>
</div>
