<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <form action="" method="get">
      <input type="hidden" name="p" value="Judul">
      <input type="hidden" name="x" value="GantiJudul">
      <input type="hidden" name="prodi" value="<?= strtolower($sess->get('prodi')) ;?>">
      <div class="col-sm-12 col-md-6">
        <div class="input-group input-group-sm">
          <input class="form-control" type="text" name="nim" placeholder="Masukkan NIM Mahasiswa">
          <span class="input-group-append">
            <button type="submit" name="go" value="refresh" class="btn btn-info btn-flat">Cari</button>
          </span>
        </div>
      </div>
    </form>

    <br/>
    <?php 
    if(!empty($data['pesan'])){?>
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <?= $data['pesan'] ;?><br/>
      </div>
      <?php
    }
    if($data['forminput']){ ?>

      <div class="card card-primary card-outline">
        <div class="card-header">
          <h3 class="card-title">Form Input Judul Offline</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
          </div>
          <!-- /.card-tools -->
        </div>
        <!-- /.card-header -->
        <div class="card-body">
          <form action="?p=Judul&x=ProsesUpdateJudul" method="post">
            <input type="hidden" name="IDJudul" value="<?= $data['row'][0]['id'];?>">
            <div class="card-body">
              <div class="form-group">
                <label class="col-sm-3 control-label">NIM</label>
                <div class="col-sm-10">
                  <input type="text" name="NIM" class="form-control" value="<?= $data['row'][0]['nim'];?>" placeholder="NIM" readonly="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-3 control-label">Program Studi</label>
                <div class="col-sm-10">
                  <input type="text" name="prodi" class="form-control" value="<?= $data['row'][0]['prodi'] == 'SK' ? 'Sistem Komputer' : 'Sistem Informasi';?>" placeholder="Program Studi" readonly="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-3 control-label">ID Judul</label>
                <div class="col-sm-10">
                  <input type="text" name="Judul" class="form-control" value="<?= $data['row'][0]['id'];?>" placeholder="ID Judul" readonly="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-3 control-label">Judul Lama</label>
                <div class="col-sm-10">
                  <input name="JudulLama" class="form-control" readonly="" value="<?= str_replace(array('<p>','</p>'), "", $data['row'][0]['judul']) ;?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-3 control-label">Judul Baru</label>
                <div class="col-sm-10">
                  <div class="mb-3">
                    <textarea id="editor1" name="JudulBaru" class="form-control" rows="10" style="width: 100%"></textarea>
                  </div>
                </div>
              </div>                 
              <div class="form-group">
                <input type="submit" name="submit" class="btn btn-info btn-flat" value="Simpan">
                <a href="?p=Judul&x=JudulProdi&prodi=sk" class="btn btn-dark btn-flat">Batal</a>
              </div>
            </div>
          </form>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
      <?php
    }
    ?>
  </div>
</div>