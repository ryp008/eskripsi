<?php 
if($sess->get('prodi')=="SI"){                  
  $prd = "Sistem Informasi";
  $kpd = "William Ramdhan, M.Kom.";
  $NIDN ="0130048702";
  $homepage = "s1is.stmik.royal.ac.id";
  $email = "prodi_si@royal.ac.id";
}else{ 
  $prd = "Sistem Komputer";
  $kpd = "Muhammad Amin, M.Kom.";
  $NIDN ="0113128502";
  $homepage = "s1cs.stmik.royal.ac.id";
  $email = "prodi_sk@royal.ac.id";
}
?>
 
<table border="0" width="100%">
    <tr>
      <td colspan="3">
        <!-- head surat -->
        <table width="100%">
          <tr>
           <td rowspan="" width="60">
            <?php            
            if($sess->get('prodi')=="SI"){
             ?>
             <img src="images/si.png" width="80" height="80"/>
             <?php }else{ ?>
               <img src="images/sk.png" width="80" height="80"/>
               <?php } ?>
             </td>
             <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
              <h4><b>STMIK ROYAL</b></h4>
              Program Studi <?= $prd ;?>
            </td>
            <td rowspan="" align="right">
             <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
           </td>
         </tr>
         <tr>
           <td colspan="3" align="center" style="font-size: 10pt">
            Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
            Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
          </tr>
          <tr>
           <td colspan="3" style="border-bottom:3px solid black;"></td>
         </tr>
         <tr>
          <td colspan="8">
            <p style="float:right;">
            </p>
          </td>
        </tr>
        <tr>
          <td colspan="8" align="center"> <strong style="font-size:16px;">SURAT TUGAS</strong> <br/><span style="font-size:14px;"> Nomor : <?= $data['surat'][0]['NoSurat'];?></span></td>
        </tr>
      </table>
      <!-- end head surat -->
    </td>
  </tr>
  <!-- Isi surat -->
  <tr>
    <td colspan="3" align="justify">
      <br/>
      <div style="font-size: 14px;">
        Bersama ini kami menugaskan kepada Bapak/Ibu dosen sebagai berikut : <br/><br/>
        <table border="" cellspacing="0" cellpadding="2" class="table table-bordered table-condensed" width="100%">
          <thead>
            <tr>
              <th>No.</th>
              <th>Nama Dosen</th>
              <th>NIDN/NIP</th>
              <th>Pembimbing</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td><?= $data['surat'][0]['Dosen1'] ;?></td>
              <td><?= $data['surat'][0]['NIDN1'];?></td>
              <td>1 (Satu)</td>
            </tr>
            <tr>
              <td>2</td>
              <td><?= $data['surat'][0]['Dosen2'] ;?></td>
              <td><?= $data['surat'][0]['NIDN2'];?></td>
              <td>2 (Dua)</td>
            </tr>
          </tbody>
        </table>
        <br/>
        <p>Untuk membimbing Skripsi mahasiswa : </p>
        <div style="padding:0 20px">
          <table>
            <tr>
              <th>Nama</th>
              <td>:</td>
              <td><?= $data['surat'][0]['Name'];?></td>
            </tr>
            <tr>
              <th>NIM</th>
              <td>:</td>
              <td><?= $data['surat'][0]['NIM'] ;?></td>
            </tr>
            <tr>
              <th>Program Studi</th>
              <td>:</td>
              <td><?= $prd ;?></td>
            </tr>
            <tr>
              <th>Judul/ Tema</th>
              <td>:</td>
              <td><?= $data['judul'][0]['judul'];?></td>
            </tr>
            <tr>
              <th>Lama Bimbingan</th>
              <td>:</td>
              <td><?php if($data['surat'][0]['Mbimbingan'] != 0000-00-00){ echo format_tanggal($data['surat'][0]['Mbimbingan'])." s/d ".format_tanggal($data['surat'][0]['Sbimbingan']);}else{echo "-";}?></td>
            </tr>
          </table>
        </div>
        <p>
          Apabila pada tanggal yang sudah ditentukan mahasiswa yang dibimbing belum selesai, maka Bapak/Ibu harus melaporkan kepada Ka. Prodi.
        </p>
        <p>
          Demikian surat tugas ini kami sampaikan, atas perhatian dan kerjasama dari Bapak/Ibu kami ucapkan terima kasih.
        </p>
      </div>
    </td>
  </tr>
  <!-- Akhir isi surat -->
  <tr>
    <!-- tanda tangan -->
    <td colspan="3">
      <div style="font-size: 14px;">

       <br/>
       <p style="float:right; margin-right:5px; width:300px; text-align:center;">
        <!-- Menyetujui, <br/><strong>Wakil Ketua 1</strong> -->
        Kisaran,______/_____/ <u> <?=date('Y')?></u><br/>
        <br/><strong><span style="margin-left: -30px">Ka. Prodi</span></strong>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <strong><u><?= $kpd ;?></u><br/>
          NIDN: <?= $NIDN ;?></strong>
        </p>
      </div>
    </td>
    <!-- akhir tanda tangan -->
  </tr>
  <tr>
    <td colspan="3" style="font-size: 10pt">
      <hr size="1">
      Dicetak Melalui Skripsi Online STMIK ROYAL Oleh <?php echo $sess->get('name') ?>  <br/>
      <strong>
       Pada
       <?php
       echo ' Tanggal '.date('d-m-Y').", Jam ";
       echo gmdate("H:i:s", time()+60*60*7)." WIB";
       ?>
     </strong>
     <br/><br/>
     &COPY;<?php echo date("Y"); ?> STMIK ROYAL Kisaran
   </td>
 </tr>
</table>