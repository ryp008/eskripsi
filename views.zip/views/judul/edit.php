<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <?php 
    if(!empty($data['pesan'])){ ?>
<div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data['pesan'] ;?><br/>
            </div>
    <?php } ?>
                <form action="?p=Judul&x=Ubah" class="form-horizontal" method="post">
                  <input type="hidden" name="id" value="<?= $data['input']['id'] ;?>">
                 <div class="form-group">
                    <label class="col-sm-3 control-label">NIM</label>
                    <div class="col-sm-10">
                      <input type="text" name="nim" class="form-control" value="<?= $data['input']['nim'] ;?>" readonly placeholder="NIM">
                    </div>
                  </div>
                   <div class="form-group">
                    <label class="col-sm-3 control-label">Program Studi</label>
                    <div class="col-sm-10">
                      <input type="hidden" name="prodi" value="<?= $data['input']['prodi'];?>">
                      <input type="text" name="NamaProdi" class="form-control" value="<?= $data['input']['prodi'] == 'SK' ? 'Sistem Komputer' : 'Sistem Informasi' ;?>" readonly placeholder="NIM">
                    </div>
                  </div>
                   <div class="form-group">
                    <label class="col-sm-3 control-label">Judul Skripsi</label>
                    <div class="col-sm-10">
                      <textarea name="Judul" class="form-control" rows="3" placeholder="Judul Skripsi" readonly=""><?= $data['input']['judul']; ?></textarea>
                    </div>
                  </div>
                   <div class="form-group">
                    <label class="col-sm-3 control-label">Objek Penilaian</label>
                    <div class="col-sm-10">
                      <input type="text" name="objek" class="form-control" value="<?= $data['input']['objek'] ;?>" placeholder="Objek Penelitian" readonly="">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Bahasa Pemrograman</label>
                    <div class="col-sm-10">
                       <input type="text" name="bahasa" class="form-control" value="<?= $data['input']['bahasa'] ;?>" placeholder="Bahasa Pemrograman" readonly="">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Instansi Penelitian</label>
                    <div class="col-sm-10">
                      <input type="text" name="instansi" class="form-control" value="<?= $data['input']['instansi'] ;?>" placeholder="Instansi Penelitian" readonly="">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Latar Belakang</label>
                    <div class="col-sm-10">
                     <textarea id="editor1" name="latar" class="form-control" rows="10" style="width: 100%"><?= $data['input']['latar'] ;?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Rumusan Masalah</label>
                    <div class="col-sm-10">
                      <textarea id="editor2" name="rumusan" class="form-control" rows="10" style="width: 100%"><?= $data['input']['rumusan'] ;?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Batasan Masalah</label>
                    <div class="col-sm-10">
                      <textarea id="editor3" name="batasan" class="form-control" rows="10" style="width: 100%"><?= $data['input']['batasan'] ;?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Tujuan Penelitian</label>
                    <div class="col-sm-10">
                     <textarea id="editor4" name="tujuan" class="form-control" rows="10" style="width: 100%"><?= $data['input']['tujuan'] ;?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Manfaat Penelitian</label>
                    <div class="col-sm-10">
                     <textarea id="editor5" name="manfaat" class="form-control" rows="10" style="width: 100%"><?= $data['input']['manfaat'] ;?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <input type="submit" name="simpan" class="btn btn-info btn-flat" value="Simpan">
                    <a href="?p=Judul" class="btn btn-dark btn-flat">Batal</a>
                  </div>
                </form>
  </div>
</div>