<div class="container-fluid">
  <!-- Info boxes -->
  <div class="row">
    <div class="col-12 col-sm-6 col-md-3">
      <div class="info-box">
        <span class="info-box-icon bg-info elevation-1"><i class="fa fa-gear"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Semua Judul</span>
          <span class="info-box-number">
            <?= $data['jml'][0]['total'] ;?>
            <small>Judul</small>
          </span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-12 col-sm-6 col-md-3">
      <div class="info-box mb-3">
        <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-google-plus"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Judul Diproses</span>
          <span class="info-box-number"><?= $data['jml'][0]['proses'] ;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->

    <!-- fix for small devices only -->
    <div class="clearfix hidden-md-up"></div>

    <div class="col-12 col-sm-6 col-md-3">
      <div class="info-box mb-3">
        <span class="info-box-icon bg-success elevation-1"><i class="fa fa-shopping-cart"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Judul Diterima</span>
          <span class="info-box-number"><?= $data['jml'][0]['acc'] ;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-12 col-sm-6 col-md-3">
      <div class="info-box mb-3">
        <span class="info-box-icon bg-warning elevation-1"><i class="fa fa-users"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Judul Ditolak</span>
          <span class="info-box-number"><?= $data['jml'][0]['tolak'] ;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
   <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h5 class="card-title">Data Semua Judul Skripsi</h5>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse">
                    <i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-widget="remove">
                    <i class="fa fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="row">
                  <div class="col-md-8">
                    <p class="text-center">
                      <strong>Tahun Akademik: <?= $data['taMinMax'][0]['start'];?> - <?= $data['taMinMax'][0]['end'];?></strong>
                    </p>

                    <div class="chart">
                      <!-- Sales Chart Canvas -->
                      <canvas id="salesChart" height="180" style="height: 180px;"></canvas>
                    </div>
                    <!-- /.chart-responsive -->
                  </div>
                  <!-- /.col -->
                  <div class="col-md-4">
                    <p class="text-center">
                      <strong>Total Judul Diajukan</strong>
                    </p>

                    <div class="progress-group">
                      Diterima
                      <span class="float-right"><b><?= $data['jml'][0]['acc'] ;?></b>/<?= $data['jml'][0]['total'] ;?></span>
                      <div class="progress progress-sm">
                        <?php 
                          //total data ditolak
                          $terima=$data['jml'][0]['acc'] ;
                          $tott=$data['jml'][0]['total'];
                          $persen_terima=($terima/$tott)*100;        
                        ?>
                        <div class="progress-bar bg-info" style="width: <?=$persen_terima?>%"></div>
                      </div>
                    </div>
                    <!-- /.progress-group -->

                    <div class="progress-group">
                      Ditolak
                      <span class="float-right"><b><?= $data['jml'][0]['tolak'] ;?></b>/<?= $data['jml'][0]['total'] ;?></span>
                      <div class="progress progress-sm">

                        <?php 
                          //total data ditolak
                          $tolak=$data['jml'][0]['tolak'] ;
                          $tot=$data['jml'][0]['total'];
                          $persen=($tolak/$tot)*100;        
                        ?>
                        <div class="progress-bar bg-success" style="width: <?=$persen?>%"></div>
                      </div>
                    </div>

                    <!-- /.progress-group -->
                    <div class="progress-group">
                      Diproses
                      <span class="float-right"><b><?= $data['jml'][0]['proses'] ;?></b>/<?= $data['jml'][0]['total'] ;?></span>
                      <div class="progress progress-sm">
                        <div class="progress-bar bg-warning" style="width: 0%"></div>
                      </div>
                    </div>
                    <!-- /.progress-group -->
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- ./card-body -->
              <div class="card-footer">
                <div class="row">
                  <div class="col-sm-12 col-md-6">
                    <div class="description-block border-right">
                      <span class="description-percentage text-success"><b>Sistem Informasi</b></span>
                      <h5 class="description-header">Total : <?= $data['jmlsi'][0]['total'] ;?> | ACC : <?= $data['jmlsi'][0]['acc'] ;?> | Tolak : <?= $data['jmlsi'][0]['tolak'] ;?> | Proses : <?= $data['jmlsi'][0]['proses'] ;?></h5>
                    </div>
                    <!-- /.description-block -->
                  </div>
                  <div class="col-sm-12 col-md-6">
                    <div class="description-block">
                      <span class="description-percentage text-primary"><b>Sistem Komputer</b></span>
                      <h5 class="description-header">Total : <?= $data['jmlsk'][0]['total'] ;?> | ACC : <?= $data['jmlsk'][0]['acc'] ;?> | Tolak : <?= $data['jmlsk'][0]['tolak'] ;?> | Proses : <?= $data['jmlsk'][0]['proses'] ;?></h5>
                    </div>
                    <!-- /.description-block -->
                  </div>
                </div>
                <!-- /.row -->
              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-sm-12 col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Judul Sistem Informasi</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-widget="remove"><i class="fa fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">                
                <div class="chart">
                  <canvas id="barChartSI" style="height:230px"></canvas>
                </div>

                <div class="d-flex flex-row justify-content-end">
                  <span class="mr-2">
                    <i class="fa fa-square text-info"></i> Diterima
                  </span>

                  <span>
                    <i class="fa fa-square text-success"></i> Ditolak &nbsp;
                     </span>

                  <span>
                    <i class="fa fa-square text-warning"></i> Diproses
                  </span>
                </div>
              </div>
            </div>
          </div>
          <!-- end -->
          <!-- start -->
          <div class="col-sm-12 col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Judul Sistem Komputer</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-widget="remove"><i class="fa fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
             <div class="card-body">                
                <div class="chart">
                  <canvas id="barChartSK" style="height:230px"></canvas>
                </div>

                <div class="d-flex flex-row justify-content-end">
                  <span class="mr-2">
                    <i class="fa fa-square text-info"></i> Diterima
                  </span>

                  <span>
                    <i class="fa fa-square text-success"></i> Ditolak &nbsp;
                     </span>

                  <span>
                    <i class="fa fa-square text-warning"></i> Diproses
                  </span>
                </div>
              </div>
            </div>
          </div>
          <!-- end -->

          <div class="col-sm-12 col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Judul Berdasarkan Tema</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-widget="remove"><i class="fa fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="row">
                  <div class="col-md-8">
                    <div class="chart-responsive">
                      <canvas id="pieChart" height="150"></canvas>
                    </div>
                    <!-- ./chart-responsive -->
                  </div>
                  <!-- /.col -->
                  <div class="col-md-4">
                    <ul class="chart-legend clearfix">
                      <li><i class="fa fa-circle-o text-danger"></i> Sistem Informasi</li>
                      <li><i class="fa fa-circle-o text-success"></i> Sistem Otomatis</li>
                      <li><i class="fa fa-circle-o text-warning"></i> SPK</li>
                      <li><i class="fa fa-circle-o text-info"></i> Sistem Pakar</li>
                      <li><i class="fa fa-circle-o text-primary"></i> Microcontoller</li>
                      <li><i class="fa fa-circle-o text-secondary"></i>Web Programming, Aplikasi Website , PHP , Java Web</li>
                    </ul>
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <div class="col-sm-12 col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Judul Berdasarkan Bahasa Pemrograman
</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-widget="remove"><i class="fa fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="row">
                  <div class="col-md-8">
                    <div class="chart-responsive">
                      <canvas id="pieChart2" height="150"></canvas>
                    </div>
                    <!-- ./chart-responsive -->
                  </div>
                  <!-- /.col -->
                  <div class="col-md-4">
                    <ul class="chart-legend clearfix">
                      <li><i class="fa fa-circle-o text-danger"></i> PHP</li>
                      <li><i class="fa fa-circle-o text-success"></i> Java</li>
                      <li><i class="fa fa-circle-o text-warning"></i> VB Net Programming</li>
                      <li><i class="fa fa-circle-o text-primary"></i> Adobe Flash</li>
                      <li><i class="fa fa-circle-o text-secondary"></i> C , C++, C AVR, Android,Delphi</li>
                    </ul>
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- /.card-body -->
            <!-- /.card -->
          </div>
        </div>
      </div>
    </div>


