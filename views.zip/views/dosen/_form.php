<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
        <form method="post" action="?p=Dosen&x=Simpan">
          <fieldset class="form-group">
            <label for="txtNIDN">NIDN</label>
            <input type="text" name="NIDN" class="form-control" placeholder="NIDN" required>
            <small class="text-muted">Nomor Induk Dosen Nasional</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">NIK</label>
            <input type="text" class="form-control" name="NIK" placeholder="NIK" required>
            <small class="text-muted">Nomor Induk Kepegawaian</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Nama</label>
            <input type="text" class="form-control" name="Name" placeholder="Nama" required>
            <small class="text-muted">Nama Lengkap</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="Gelar">Gelar</label>
            <input type="text" class="form-control" name="Gelar" placeholder="Gelar" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Jenis Kelamin</label><br/>
            <input type="radio" name="Sex" value="L">Laki laki<br/>
            <input type="radio" name="Sex" value="P">Perempuan
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Tanggal Lahir</label>
            <input type="text" class="form-control" name="TglLahir" placeholder="YYYY-MM-DD" required>
            <small class="text-muted"></small>
          </fieldset>

<fieldset class="form-group">
            <label for="">Tempat Lahir</label>
            <input type="text" class="form-control" name="TempatLahir" placeholder="Tempat Lahir" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="txtNamaLengkap">Alamat</label>
            <textarea name="Alamat" id="alamat" class="form-control" rows="8" cols="80" required></textarea>
            <small class="text-muted">Alamat lengkap mahasiswa</small>
          </fieldset>
          
          <fieldset class="form-group">
            <label for="">Email</label>
            <input type="email" class="form-control" name="Email" placeholder="e-mail" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">No. Telepon</label>
            <input type="text" class="form-control" name="Phone" placeholder="Nomor Telepon" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Jenjang Pendidikan</label>
            <select class="form-control" name="Jenjang" required="">
              <option value="">-Pilih-</option>
              <?php 
              foreach ($data['jenjang'] as $value) {
                echo "<option value='".$value['Kode']."'> $value[Nama]</option>";
              }
              ?>
            </select>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Lulusan PT</label>
            <input type="text" class="form-control" name="LulusanPT" placeholder="Lulusan Perguruan Tinggi" required>
            <small class="text-muted"></small>
          </fieldset>

          <button type="submit" name="simpan" class="btn btn-success"> <i class="fa fa-save" aria-hidden></i> Simpan </button>
          <a href="?p=Dosen" class="btn btn-danger"> <i class="fa fa-history

          " aria-hidden></i> Kembali</a>
        </form>
      </div>
    </div>
