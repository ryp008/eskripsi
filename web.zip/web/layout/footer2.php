        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<footer class="main-footer">
  <strong>Copyright &copy; 2015-<?=date('Y')?> <a href="http://rnstudio.id">R & N Studio</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>version</b> 1.0.1
  </div>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- jQuery -->
<script src="../vendor/AdminLTE-3/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="../vendor/js/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
$.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="../vendor/AdminLTE-3/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- datatables -->

<script src="../vendor/AdminLTE-3/plugins/datatables/jquery.dataTables.js"></script>
<script src="../vendor/AdminLTE-3/plugins/datatables/dataTables.bootstrap4.js"></script>

<!-- angularjs -->
<script src="../vendor/AngularJS/angular.min.js"></script>


<!-- Morris.js charts -->
<script src="../vendor/js/raphael-min.js"></script>
<!--<script src="../vendor/AdminLTE-3/plugins/morris/morris.min.js"></script> -->
<script src="../vendor/AdminLTE-3/plugins/chartjs-old/Chart.min.js"></script>

<!-- Sparkline -->
<script src="../vendor/AdminLTE-3/plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="../vendor/AdminLTE-3/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="../vendor/AdminLTE-3/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="../vendor/AdminLTE-3/plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="../vendor/js/moment.min.js"></script>
<script src="../vendor/AdminLTE-3/plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="../vendor/AdminLTE-3/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- CK Editor -->
<script src="../vendor/ckeditor/ckeditor.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="../vendor/AdminLTE-3/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="../vendor/AdminLTE-3/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../vendor/AdminLTE-3/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../vendor/Parsley.js-2.8.1/dist/parsley.min.js"></script>
  <script src="../vendor/Parsley.js-2.8.1/dist/i18n/id.js"></script>
<script src="../vendor/AdminLTE-3/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../vendor/AdminLTE-3/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../vendor/AdminLTE-3/dist/js/demo.js"></script>
<script src="../vendor/js/jryp.js"></script>

<!--<script src="../vendor/js/statistik.js"></script> -->


<!-- script utk page table -->
<script>
  $(function () {
    $("#dtskripsi").DataTable();
    $("#dtskripsi3").DataTable();
    $('#dtskripsi2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>

<script>
  $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();
  });
</script>
<?php 
if(@$_GET['p'] == 'Statistik'){ ?>
<script>
  $(function () {
 // Get context with jQuery - using jQuery's .get() method.
  var salesChartCanvas = $('#salesChart').get(0).getContext('2d')
  // This will get the first returned node in the jQuery collection.
  var salesChart       = new Chart(salesChartCanvas)

  var salesChartData = {
    <?php 
    $label = '';
    foreach ($data['ta'] as $value) {
      $label .= ",'".$value['kode']."'";
    } ?>
    labels  :[<?= substr($label,1) ;?>],//['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [
      {
        label               : 'ACC',
        fillColor           : '#17a2b8',
        strokeColor         : '#ced4da',
        pointColor          : '#17a2b8',
        pointStrokeColor    : '#c1c7d1',
        pointHighlightFill  : '#fff',
        pointHighlightStroke: 'rgb(220,220,220)',
        data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['acc'.$key['kode']][0]['Jacc'].","; }?>]
      },
      {
        label               : 'TOLAK',
        fillColor           : 'rgba(32, 201, 151, 0.7)',
        strokeColor         : 'rgba(32, 201, 151, 1)',
        pointColor          : '#28a745',
        pointStrokeColor    : 'rgba(0, 123, 255, 1)',
        pointHighlightFill  : '#fff',
        pointHighlightStroke: 'rgba(0, 123, 255, 1)',
        data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['tolak'.$key['kode']][0]['Jtolak'].","; }?>]
      },
      {
        label               : 'PROSES',
        fillColor           : 'rgba(255, 193, 7, 0.8)',
        strokeColor         : 'rgba(255, 193, 7, 1)',
        pointColor          : '#ffc107',
        pointStrokeColor    : 'rgba(0, 123, 255, 1)',
        pointHighlightFill  : '#fff',
        pointHighlightStroke: 'rgba(0, 123, 255, 1)',
        data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['proses'.$key['kode']][0]['Jproses'].","; }?>]
      }
    ]
  }

  var salesChartOptions = {
    //Boolean - If we should show the scale at all
    showScale               : true,
    //Boolean - Whether grid lines are shown across the chart
    scaleShowGridLines      : false,
    //String - Colour of the grid lines
    scaleGridLineColor      : 'rgba(0,0,0,.05)',
    //Number - Width of the grid lines
    scaleGridLineWidth      : 1,
    //Boolean - Whether to show horizontal lines (except X axis)
    scaleShowHorizontalLines: true,
    //Boolean - Whether to show vertical lines (except Y axis)
    scaleShowVerticalLines  : true,
    //Boolean - Whether the line is curved between points
    bezierCurve             : true,
    //Number - Tension of the bezier curve between points
    bezierCurveTension      : 0.3,
    //Boolean - Whether to show a dot for each point
    pointDot                : false,
    //Number - Radius of each point dot in pixels
    pointDotRadius          : 4,
    //Number - Pixel width of point dot stroke
    pointDotStrokeWidth     : 1,
    //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
    pointHitDetectionRadius : 20,
    //Boolean - Whether to show a stroke for datasets
    datasetStroke           : true,
    //Number - Pixel width of dataset stroke
    datasetStrokeWidth      : 2,
    //Boolean - Whether to fill the dataset with a color
    datasetFill             : true,
    //String - A legend template
    legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%=datasets[i].label%></li><%}%></ul>',
    //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio     : false,
    //Boolean - whether to make the chart responsive to window resizing
    responsive              : true
  }

  //Create the line chart
  salesChart.Line(salesChartData, salesChartOptions)

  //---------------------------
  //- END MONTHLY SALES CHART -
  //---------------------------
    })

        //-------------
  //- PIE CHART -
  //-------------
  // Get context with jQuery - using jQuery's .get() method.
  var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
  var pieChart       = new Chart(pieChartCanvas)
  var PieData        = [
    {
      value    : <?= $data['tema'][0]['SistemInformasi'];?>,
      color    : '#dc3545',
      highlight: '#dc3545',
      label    : 'Sistem Informasi'
    },
    {
      value    : <?= $data['tema'][0]['otomatis'];?>,
      color    : '#28a745',
      highlight: '#28a745',
      label    : 'Sistem Otomatis'
    },
    {
      value    : <?= $data['tema'][0]['spk'];?>,
      color    : '#ffc107',
      highlight: '#ffc107',
      label    : 'SPK'
    },
    {
      value    : <?= $data['tema'][0]['pakar'];?>,
      color    : '#17a2b8',
      highlight: '#17a2b8',
      label    : 'Sistem Pakar'
    },
    {
      value    : <?= $data['tema'][0]['micro'];?>,
      color    : '#007bff',
      highlight: '#007bff',
      label    : 'Microcontoller'
    },
    {
      value    : <?= $data['tema'][0]['web'];?>,
      color    : '#6c757d',
      highlight: '#6c757d',
      label    : 'Web Programming, PHP, Android'
    }
  ]
  var pieOptions     = {
    //Boolean - Whether we should show a stroke on each segment
    segmentShowStroke    : true,
    //String - The colour of each segment stroke
    segmentStrokeColor   : '#fff',
    //Number - The width of each segment stroke
    segmentStrokeWidth   : 1,
    //Number - The percentage of the chart that we cut out of the middle
    percentageInnerCutout: 50, // This is 0 for Pie charts
    //Number - Amount of animation steps
    animationSteps       : 100,
    //String - Animation easing effect
    animationEasing      : 'easeOutBounce',
    //Boolean - Whether we animate the rotation of the Doughnut
    animateRotate        : true,
    //Boolean - Whether we animate scaling the Doughnut from the centre
    animateScale         : false,
    //Boolean - whether to make the chart responsive to window resizing
    responsive           : true,
    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio  : false,
    //String - A legend template
    legendTemplate       : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>',
    //String - A tooltip template
    tooltipTemplate      : '<%=value %> <%=label%> Judul'
  }
  //Create pie or douhnut chart
  // You can switch between pie and douhnut using the method below.
  pieChart.Doughnut(PieData, pieOptions)

  var pieChartCanvas = $('#pieChart2').get(0).getContext('2d')
  var pieChart       = new Chart(pieChartCanvas)
  var PieData        = [
    {
      value    : <?= $data['bhs'][0]['php'];?>,
      color    : '#dc3545',
      highlight: '#dc3545',
      label    : 'PHP'
    },
    {
      value    : <?= $data['bhs'][0]['java'];?>,
      color    : '#28a745',
      highlight: '#28a745',
      label    : 'Java'
    },
    {
      value    : <?= $data['bhs'][0]['vb'];?>,
      color    : '#ffc107',
      highlight: '#ffc107',
      label    : 'VB Net'
    },
    {
      value    : <?= $data['bhs'][0]['android'];?>,
      color    : '#007bff',
      highlight: '#007bff',
      label    : 'Adobe Flash'
    },
    {
      value    : <?= $data['bhs'][0]['flash'];?>,
      color    : '#17a2b8',
      highlight: '#17a2b8',
      label    : 'Android'
    }
   ]
  var pieOptions     = {
    //Boolean - Whether we should show a stroke on each segment
    segmentShowStroke    : true,
    //String - The colour of each segment stroke
    segmentStrokeColor   : '#fff',
    //Number - The width of each segment stroke
    segmentStrokeWidth   : 1,
    //Number - The percentage of the chart that we cut out of the middle
    percentageInnerCutout: 50, // This is 0 for Pie charts
    //Number - Amount of animation steps
    animationSteps       : 100,
    //String - Animation easing effect
    animationEasing      : 'easeOutBounce',
    //Boolean - Whether we animate the rotation of the Doughnut
    animateRotate        : true,
    //Boolean - Whether we animate scaling the Doughnut from the centre
    animateScale         : false,
    //Boolean - whether to make the chart responsive to window resizing
    responsive           : true,
    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio  : false,
    //String - A legend template
    legendTemplate       : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>',
    //String - A tooltip template
    tooltipTemplate      : '<%=value %> <%=label%> Judul'
  }
  //Create pie or douhnut chart
  // You can switch between pie and douhnut using the method below.
  pieChart.Doughnut(PieData, pieOptions)
  //-----------------
  //- END PIE CHART -
  //-----------------

  var areaChartDataSI = {
      <?php 
      $label ='';
      foreach ($data['ta'] as $value) {
      $label .= ",'".$value['kode']."'";
    } ?>
      labels  : [<?= substr($label,1) ;?>],
      datasets: [
        {
          label               : 'Diterima',
          fillColor           : 'rgba(23, 162, 184, 1)',
          strokeColor         : 'rgba(23, 162, 184, 1)',
          pointColor          : 'rgba(23, 162, 184, 1)',
          pointStrokeColor    : '#c1c7d1',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['accsi'.$key['kode']][0]['Jacc'].","; }?>]
        },
        {
          label               : 'Ditolak',
          fillColor           : 'rgba(60,141,188,0.9)',
          strokeColor         : 'rgba(60,141,188,0.0)',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['tolaksi'.$key['kode']][0]['Jtolak'].","; }?>]
        },
        {
          label               : 'Diproses',
          fillColor           : 'rgba(255, 242, 7, 0.9)',
          strokeColor         : 'rgba(255, 242, 7, 0.9)',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['prosessi'.$key['kode']][0]['Jproses'].","; }?>]
        }
      ]
    }

    var areaChartDataSK = {
      <?php 
      $label ='';
      foreach ($data['ta'] as $value) {
      $label .= ",'".$value['kode']."'";
    } ?>
      labels  : [<?= substr($label,1) ;?>],
      datasets: [
        {
          label               : 'Diterima',
          fillColor           : 'rgba(23, 162, 184, 1)',
          strokeColor         : 'rgba(23, 162, 184, 1)',
          pointColor          : 'rgba(23, 162, 184, 1)',
          pointStrokeColor    : '#c1c7d1',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['accsk'.$key['kode']][0]['Jacc'].","; }?>]
        },
        {
          label               : 'Ditolak',
          fillColor           : 'rgba(60,141,188,0.9)',
          strokeColor         : 'rgba(60,141,188,0.0)',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['tolaksk'.$key['kode']][0]['Jtolak'].","; }?>]
        },
        {
          label               : 'Diproses',
          fillColor           : 'rgba(255, 242, 7, 0.9)',
          strokeColor         : 'rgba(255, 242, 7, 0.9)',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : [<?php foreach($data['ta'] as $key) {
                                  echo $data['prosessk'.$key['kode']][0]['Jproses'].","; }?>]
        }
      ]
    }
   //-------------
    //- BAR CHART -
    //-------------
    var barChartCanvas                   = $('#barChartSI').get(0).getContext('2d')
    var barChartSI                         = new Chart(barChartCanvas)
    var barChartData                     = areaChartDataSI
    barChartData.datasets[1].fillColor   = '#00a65a'
    barChartData.datasets[1].strokeColor = '#00a65a'
    barChartData.datasets[1].pointColor  = '#00a65a'
    var barChartOptions                  = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero        : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - If there is a stroke on each bar
      barShowStroke           : true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth          : 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing         : 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing       : 1,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to make the chart responsive
      responsive              : true,
      maintainAspectRatio     : true
    }

    barChartOptions.datasetFill = false
    barChartSI.Bar(barChartData, barChartOptions)


     var barChartCanvas                   = $('#barChartSK').get(0).getContext('2d')
    var barChartSK                         = new Chart(barChartCanvas)
    var barChartData                     = areaChartDataSK
    barChartData.datasets[1].fillColor   = '#00a65a'
    barChartData.datasets[1].strokeColor = '#00a65a'
    barChartData.datasets[1].pointColor  = '#00a65a'
    var barChartOptions                  = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero        : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - If there is a stroke on each bar
      barShowStroke           : true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth          : 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing         : 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing       : 1,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to make the chart responsive
      responsive              : true,
      maintainAspectRatio     : true
    }

    barChartOptions.datasetFill = false
    barChartSK.Bar(barChartData, barChartOptions)
  
  
</script>

<?php } ?>

<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor1'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });

      ClassicEditor
      .create(document.querySelector('#editor2'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });

      ClassicEditor
      .create(document.querySelector('#editor3'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });

      ClassicEditor
      .create(document.querySelector('#editor4'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      })

      ClassicEditor
      .create(document.querySelector('#editor5'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      })
  })


</script>

<script>
  $(function () {
     // bootstrap WYSIHTML5 - text editor

    $('.textarea-form').wysihtml5({
      toolbar: { fa: true }
    })
  })
</script>

</body>
</html>
