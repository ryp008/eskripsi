<div class="container-fluid">
  <!-- Info boxes -->
  <div class="row">
    <div class="col-12 col-sm-6 col-md-3">
      <div class="info-box">
        <span class="info-box-icon bg-info elevation-1"><i class="fa fa-book"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Semua Judul</span>
          <span class="info-box-number">
            <?= $data['jml'][0]['total'] ;?>
            <small>Judul</small>
          </span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-12 col-sm-6 col-md-3">
      <div class="info-box mb-3">
        <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-clock-o"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Judul Diproses</span>
          <span class="info-box-number"><?= $data['jml'][0]['proses'] ;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->

    <!-- fix for small devices only -->
    <div class="clearfix hidden-md-up"></div>

    <div class="col-12 col-sm-6 col-md-3">
      <div class="info-box mb-3">
        <span class="info-box-icon bg-success elevation-1"><i class="fa fa-check-circle"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Judul Diterima</span>
          <span class="info-box-number"><?= $data['jml'][0]['acc'] ;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-12 col-sm-6 col-md-3">
      <div class="info-box mb-3">
        <span class="info-box-icon bg-warning elevation-1"><i class="fa fa-close"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Judul Ditolak</span>
          <span class="info-box-number"><?= $data['jml'][0]['tolak'] ;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h5 class="card-title"><?= $data['sub_title'];?></h5>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse">
              <i class="fa fa-minus"></i>
            </button>
                  <!--
                  <div class="btn-group">
                    <button type="button" class="btn btn-tool dropdown-toggle" data-toggle="dropdown">
                      <i class="fa fa-wrench"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right" role="menu">
                      <a href="#" class="dropdown-item">Action</a>
                      <a href="#" class="dropdown-item">Another action</a>
                      <a href="#" class="dropdown-item">Something else here</a>
                      <a class="dropdown-divider"></a>
                      <a href="#" class="dropdown-item">Separated link</a>
                    </div>
                  </div>
                -->
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <form action="" method="get">
                <input type="hidden" value="Index" name="p">
                <div class="row">
                  <div class="col-sm-12 col-md-3 text-right">
                    <label>Pencarian Judul Skripsi</label>
                  </div>
                  <div class="col-sm-12 col-md-9">
                <div class="input-group input-group-md">
                  <input type="text" name="key" class="form-control" placeholder="NIM atau Judul Skripsi" required="">
                  <span class="input-group-append">
                    <button type="submit" name="go" value="cari" class="btn btn-danger btn-flat">Go!</button>
                    <a href="?p=Index" class="btn btn-success btn-flat">Reset</a>
                  </span>
                </div>
              </div>
            </div>
              </form>
              <br/>
<?php if(isset($_GET['go']))
{ 
  for($i=0; $i<count($data['judul']); $i++) {
                        ?>
              <div class="card card-widget">
                <div class="card-header">
                  <div class="user-block">
                    <img class="img-circle" src="./images/user-avatar.png" alt="User Image">
                    <span class="username"><a href="#"><?= $data['judul'][$i]['Name']." | ".$data['judul'][$i]['NIM']." | ".$data['judul'][$i]['KodeJurusan'] ;?></a></span>
                    <span class="description"><?= $data['judul'][$i]['tgl_pengajuan'];?></span>
                  </div>
                  <!-- /.user-block -->
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
                      <i class="fa fa-circle-o"></i></button>
                      <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-tool" data-widget="remove"><i class="fa fa-times"></i>
                      </button>
                    </div>
                    <!-- /.card-tools -->
                    <h5 class="panel-title text-center"><?= $data['judul'][$i]['judul']?></h5>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                      <p class="text-justify"><?= substr($data['judul'][$i]['latar'],0,500)?></p>  
                  </div>
                  <!-- /.card-body -->
                  <div class="row">
                    <div class="col-sm-12 col-md-6">
                      <div class="card-footer" style="font-size: 12px">
                        Intansi : <?= $data['judul'][$i]['instansi'] ;?><br/>
                        Objek : <?= $data['judul'][$i]['objek'] ;?>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                      <div class="card-footer" style="font-size: 12px">
                        <div class="row">
                        <div class="col-sm-12 col-md-6">
                          <button class="btn btn-default btn-social btn-thumbs-o-up">
                            <i class="fa fa-thumbs-o-up"></i> <?= $data['judul'][$i]['status'] ;?></button>
                          </div>

                          <div class="col-sm-12 col-md-6">
                            <div class="hidden-md-up">
                            <button class="btn btn-default btn-social btn-code pull-right">
                              <i class="fa fa-code"></i> <?= $data['judul'][$i]['bahasa'] ;?>        </button>
                            </div>
                          </div>
                          </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <?php 
                  }


}else{
                        for($i=0; $i<count($data['judul']); $i++) {
                        ?>
              <div class="card card-widget">
                <div class="card-header">
                  <div class="user-block">
                    <img class="img-circle" src="./images/user-avatar.png" alt="User Image">
                    <span class="username"><a href="#"><?= $data['judul'][$i]['Name']." | ".$data['judul'][$i]['NIM']." | ".$data['judul'][$i]['KodeJurusan'] ;?></a></span>
                    <span class="description"><?= $data['judul'][$i]['tgl_pengajuan'];?></span>
                  </div>
                  <!-- /.user-block -->
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
                      <i class="fa fa-circle-o"></i></button>
                      <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-tool" data-widget="remove"><i class="fa fa-times"></i>
                      </button>
                    </div>
                    <!-- /.card-tools -->
                    <h5 class="panel-title text-center"><?= $data['judul'][$i]['judul']?></h5>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                      <p class="text-justify"><?= substr($data['judul'][$i]['latar'],0,500)?></p>  
                  </div>
                  <!-- /.card-body -->
                  <div class="row">
                    <div class="col-sm-12 col-md-6">
                      <div class="card-footer" style="font-size: 12px">
                        Intansi : <?= $data['judul'][$i]['instansi'] ;?><br/>
                        Objek : <?= $data['judul'][$i]['objek'] ;?>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                      <div class="card-footer" style="font-size: 12px">
                        <div class="row">
                        <div class="col-sm-12 col-md-6">
                          <button class="btn btn-default btn-social btn-thumbs-o-up">
                            <i class="fa fa-thumbs-o-up"></i> <?= $data['judul'][$i]['status'] ;?></button>
                          </div>

                          <div class="col-sm-12 col-md-6">
                            <div class="hidden-md-up">
                            <button class="btn btn-default btn-social btn-code pull-right">
                              <i class="fa fa-code"></i> <?= $data['judul'][$i]['bahasa'] ;?>        </button>
                            </div>
                          </div>
                          </div>
                          </div>
                        </div>
                      </div>
                    </div>
<?php }
} ?>
                  </div>
                </div>
                <!-- ./card-body -->
              </div>
              <!-- /.card -->
              </div>
            <!-- /.col -->

          </div>
        </div>