<a href="?p=Bahasa&x=Tambah" class="btn btn-outline-success"><strong> <i class="fa fa-plus"></i> Tambah Bahasa</strong></a>
<br/>
<br/>
<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <table class="table table-bordered table-striped" id="dtskripsi">
      <thead>
        <tr>
          <th>No.</th>
          <th>Bahasa</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $no=0;
        foreach ($data['bahasa'] as $value) { ?>
        <tr>
          <td><?= ++$no; ?></td>
          <td><?= $value['nama'];?></td>
          <td align="center">
              <a href="?p=Bahasa&x=EditBahasa&id=<?= $value['id'];?>" class="btn btn-dark btn-sm btn-flat"><i class="fa fa-pencil"></i>
              <a href="?p=Bahasa&x=Hapus&id=<?= $value['id'];?>" class="btn btn-danger btn-sm btn-flat"  onclick="return confirm('Yakin akan dihapus')"><i class="fa fa-trash"></i></a>
          </td>
        </tr>
          <?php
        } ?>
      </tbody>
    </table>
  </div>
</div>