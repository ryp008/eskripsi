  <?php 
      $tahun = filter_input(INPUT_GET, 'tahun');
      $prodi = filter_input(INPUT_GET, 'prodi');
      ?>
<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <form class="" method="get" action="?p=Pembayaran&x=allpembayaran">
                    <input type="hidden" name="p" value="Pembayaran">
                    <input type="hidden" name="x" value="allpembayaran">
                    <div class="form-group">
                    <div class="row">
                      <label class="col-sm-12 col-md-2 text-right">Tahun</label>
                      <div class="col-sm-12 col-md-4">
                        <select name="tahun" required="">
                          <option value="semua">Semua</option>
                        <?php
                         foreach ($data['ta'] as $row) {
                          $tahun == $row['kode'] ? $s='selected' : $s='';
                          echo "<option value='".$row['kode']."' $s>$row[tahun]</option>";
                        }
                        ?>
                        </select>
                      </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="row">
                      <label class="col-sm-12 col-md-2 text-right">Program Studi</label>
                      <div class="col-sm-12 col-md-4">
                        <select name="prodi">
                          <option value="semua">Semua</option>
                          <?php 
                          $optionprodi = array('SI' => 'Sistem Informasi', 'SK'=>'Sistem Komputer');
                          foreach ($optionprodi as $value =>$key) {
                          $prodi == $value ? $s='selected' : $s='';
                            echo "<option value='".$value."' $s>$key</option>";
                          }
                          ?>
                        </select>
                      </div>
                    </div>
                  </div>
                    <div class="form-group">
                    <div class="row">
                      <div class="col-sm-12 offset-md-2">
                        <input type="submit" name="go" value="Refresh" class="btn btn-danger btn-sm btn-flat">
                      </div>
                    </div>
                    </div>
                  </form>
                  <br/>
                  <table class="table table-bordered table-striped table-sm" id="dtskripsi">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Sts Skripsi</th>
                    <th>Sts Pembayaran</th>
                    <th>Tgl Bayar</th>
                  <th>Option</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  $no =0;
                  foreach ($data['all'] as $key) {?>
                    <tr>
                      <td><?= ++$no ;?></td>
                      <td><?= $key['NIM']; ?></td>
                      <td><?= $key['Name'];?></td>
                      <td align="center"><?= $key['Status'] == 1 ? 'Aktif' : 'Pasif';?></td>
                      <td align="center"><?= $key['STATUS_BYR'];?></td>
                      <td><?= $key['tgl_bayar'];?></td>
                      <td align="center">
                        <?php 
                        if($key['STATUS_BYR'] != 'LUNAS'){?>
                        <a href="?p=Pembayaran&x=bayar&nim=<?= $key['NIM'] ;?>" class="btn btn-info btn-sm btn-flat">Bayar</a>
                        <?php } ?>
                         <?php if($sess->get('level') == 1){ ?>
                          <a href="?p=Pembayaran&x=Hapus&id=<?= $key['NIM'] ;?>" class="btn btn-danger btn-sm btn-flat">Hapus</a>
                          <?php } ?>
                      </td>
                    </tr>
                  <?php }?>
                </tbody>
              </table>
            </div>
          </div>
