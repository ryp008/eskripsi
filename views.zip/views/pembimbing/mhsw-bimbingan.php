<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-justified nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#pembimbing1" data-toggle="tab">Pembimbing 1</a></li>
                  <li class="nav-item"><a class="nav-link" href="#pembimbing2" data-toggle="tab">Pembimbing 2</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="active tab-pane" id="pembimbing1">
                    <table class="table table-bordered table-sm table-striped" id="dtskripsi">
                      <thead>
                        <tr>
                          <th width="30px">No.</th>
                          <th>NIM</th>
                          <th>Nama</th>
                          <th>Prodi</th>
                          <th>Judul</th>
                          <th>Tahun</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no=0;
                        foreach ($data['dosen1'] as $key) { ?>
                          <tr>
                            <td><?= ++$no ;?></td>
                            <td>
                              <a href="" onclick="cetak_slip('?p=Judul&x=Detail&id=<?= $key['id'] ?>','Judul Mahasiswa','width=800,height=600,scrollbars=yes')" class="btn btn-info btn-sm" data-toggle="tooltip" title="Lihat Selengkapnya">
                              <?= $key['NIM'];?></a></td>
                            <td><?= $key['Name'];?></td>
                            <td><?= $key['Prodi'];?></td>
                            <td><?= $key['judul'];?></td>
                            <td><?= $key['tahun'];?></td>
                            <td><?= $key['status'];?></td>
                          </tr>
                          <?php
                        } ?>
                      </tbody>
                    </table>
                  </div>
                  <div class="tab-pane" id="pembimbing2">
                    <table class="table table-bordered table-sm table-striped" id="dtskripsi3">
                      <thead>
                        <tr>
                          <th width="30px">No.</th>
                          <th>NIM</th>
                          <th>Nama</th>
                          <th>Prodi</th>
                          <th>Judul</th>
                          <th>Tahun</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no=0;
                        foreach ($data['dosen2'] as $key) { ?>
                          <tr>
                            <td><?= ++$no ;?></td>
                            <td><a href="" onclick="cetak_slip('?p=Judul&x=Detail&id=<?= $key['id'] ?>','Judul Mahasiswa','width=800,height=600,scrollbars=yes')" class="btn btn-info btn-sm" data-toggle="tooltip" title="Lihat Selengkapnya">
                              <?= $key['NIM'];?></a></td>
                            <td><?= $key['Name'];?></td>
                            <td><?= $key['Prodi'];?></td>
                            <td><?= $key['judul'];?></td>
                            <td><?= $key['tahun'];?></td>
                            <td><?= $key['status'];?></td>
                          </tr>
                          <?php
                        } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
  </div>
</div>
