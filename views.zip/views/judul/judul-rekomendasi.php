<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <table class="table table-bordered table-sm" id="dtskripsi">
      <thead>
        <tr>
          <th>No.</th>
          <th>NIM & Name</th>
          <th>Judul</th>
          <th>Rekmndsikn</th>
          <th>Tgl Rkmndsi</th>
          <th>Tahun</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $no=0;
        foreach ($data['judul'] as $key) { ?>
          <tr>
            <td><?= ++$no; ?></td>
            <td>
              <?php 
              if($key['status'] == 'SEDANG DIPROSES'){ ?>
                <a href="" onclick="cetak_slip('?p=Judul&x=DetailProses&id=<?= $key['id'] ?>','Judul Mahasiswa','width=800,height=600,scrollbars=yes')" class="btn btn-info btn-sm" data-toggle="tooltip" title="Proses Judul">
                  <?= $key['NIM']."<br/>".$key['Name'];?></a>
                  <?php }else{ ?>
                    <a href="" onclick="cetak_slip('?p=Judul&x=Detail&id=<?= $key['id'] ?>','Judul Mahasiswa','width=800,height=600,scrollbars=yes')" class="btn btn-info btn-sm" data-toggle="tooltip" title="Proses Judul">
                      <?= $key['NIM']."<br/>".$key['Name'];?></a>
                      <?php } ?>
                    </td>
                    <td><?= $key['judul'];?></td>
                    <td align="center"><?= $key['rekomendasi'] ;?></td>
                    <td><?= $key['tgl_rekom'];?></td>
                    <td><?= $key['tahun'];?></td>
                    <td align="center">
                      <?php 
                      if($sess->get('level') == 2){
                        $disabled ='';
                        if($key['status'] == 'SUDAH ACC' or $key['status'] == 'SUDAH DITOLAK'){
                         echo $key['status'];
                       }else{
                        if($key['rekomendasi'] == 'BELUM'){
                          echo 'Proses';
                        }else{ ?>
                          <a href="?p=Judul&x=AccJudul&id=<?= $key['id'];?>&nim=<?= $key['NIM'];?>&sts=1" class="btn btn-info btn-sm btn-flat" onclick="return confirm('Apakah yakin ingin menerima judul ini?')">ACC</a>
                          <a href="?p=Judul&x=TolakJudul&id=<?= $key['id'];?>&nim=<?= $key['NIM'];?>&sts=2" class="btn btn-danger btn-sm btn-flat" onclick="return confirm('Apakah yakin ingin menolak judul ini?')">Tolak</a>
                          <?php }
                        }
                      }else{ 
                        echo $key['status']; 
                      }
                      ?>
                    </td>
                  </tr>
                  <?php 
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>