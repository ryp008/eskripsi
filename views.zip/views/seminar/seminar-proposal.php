<div class="card">
        <div class="card-header">
          <h5 class="card-title"><?= $data['sub_title'];?></h5>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse">
              <i class="fa fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-widget="remove">
              <i class="fa fa-times"></i>
          </button>
      </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <table class="table table-bordered table-hover table-striped table-sm" id="dtskripsi">
      <thead>
        <tr>
          <th>No.</th>
          <th>NIM</th>
          <th>Nama</th>
          <th>Ketua</th>
          <th>Gel.</th>
          <th>Tahun</th>
          <?php if($sess->get('level') == 3){ ?><th>Berkas</th> <?php } ?>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $no=0;
        foreach ($data['seminar'] as $value) { ?>
          <tr>
            <td><?= ++$no;?></td>
            <td><?= $value['NIM'];?></td>
            <td><?= $value['Name'];?></td>
            <td><?= $value['Ketua'];?></td>
            <td>Gel. <?= $value['Gelombang'];?></td>
            <td><?= $value['Tahun'];?></td>
            <?php if($sess->get('level') == 3){ ?>
            <td align="center">
              <a href="" onclick="cetak_slip('?p=Seminar&x=CetakBerkasSempro&id=<?= $value['IDSeminar']?>','Berkas Seminar Proposal','width=800,height=600,scrollbars=yes')" class="btn btn-info btn-sm btn-flat" data-toggle="tooltip" title="Cetak berkas sempro"><i class="fa fa-print"></i> Cetak</a>
            </td>
            <?php } ?>
            <td align="center">
              <a href="?p=Seminar&x=DetSempro&id=<?= $value['IDSeminar'];?>"><i class="fa fa-folder-open-o"></i>
              </a>
              <?php if($sess->get('level') == 1 or $sess->get('level') ==3 ){ ?>
              |
              <a href="?p=Seminar&x=EditSempro&id=<?= $value['IDSeminar'];?>"><i class="fa fa-pencil"></i></a>
              <?php 
            }
              if($sess->get('level') == 1){ ?>
                | 
              <a href="?p=Seminar&x=HapusSempro&id=<?= $value['IDSeminar'];?>&nim=<?= $value['NIM'];?>" Onclick="return confirm('Yakin ingin dihapus?')"><i class="fa fa-trash"></i></a>
              <?php } ?>
            </td>
          </tr>
         <?php  
        }?>
      </tbody>
    </table>
  </div>
</div>