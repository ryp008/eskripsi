<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h5 class="card-title"> <i class="fa fa-user-plus" aria-hidden></i>  Update Data Mahasiswa</h5>
      </div>
      <div class="card-body">
        <form method="post" action="?p=Mahasiswa&x=Update">
          <fieldset class="form-group">
            <label for="txtNim">NIM</label>
            <input type="text" name="nim" id="nim" value="<?=$data[0]['nim']?>" class="form-control" placeholder="Masukkan Nim" required>
            <small class="text-muted">Nomor induk mahasiswa</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtNamaLengkap">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?=$data[0]['namalengkap']?>" placeholder="Nama lengkap" required>
            <small class="text-muted">Nama lengkap mahasiswa</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtEmail">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?=$data[0]['email']?>" placeholder="Email Aktif" required>
            <small class="text-muted">Email valid mahasiswa</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtNamaLengkap">Alamat</label>
            <textarea name="alamat" id="alamat" class="form-control" rows="8" cols="80" required><?=$data[0]['alamat']?></textarea>
            <small class="text-muted">Alamat lengkap mahasiswa</small>
          </fieldset>
          <button type="submit" class="btn btn-success"> <i class="fa fa-edit" aria-hidden></i> Update</button>
          <a href="?p=Mahasiswa" class="btn btn-danger"> <i class="fa fa-history" aria-hidden></i> Kembali</a>
        </form>
      </div>
    </div>
  </div>
</div>
