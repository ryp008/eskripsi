<?php 
$tahun = filter_input(INPUT_GET, 'thn') == '' ? '' : filter_input(INPUT_GET, 'thn');
$key = filter_input(INPUT_GET, 'key') == '' ? '' : filter_input(INPUT_GET, 'key');
$sts = filter_input(INPUT_GET, 'sts') == '' ? '' : filter_input(INPUT_GET, 'sts');

$link = '';
if(!empty($tahun)){
    $link .= "&thn=$tahun";
}
if(!empty($key)){
    $link .= "&key=$key";
}
if(!empty($sts)){
    $link .= "&sts=$sts";
}
?>
<div class="row">
    <div class="col-md-12 col-xs-12">
        <h2>
            <a href="?p=Judul&x=Pengajuan" class="btn btn-info" data-toggle="tooltip" title="Tambah Judul Baru"> <i class="fa fa-plus"></i> Tambah Judul Baru</a>
            <a href="?p=Judul&x=Offline" class="btn btn-info" data-toggle="tooltip" title="Tambah Judul Offline"> <i class="fa fa-plus"></i> Tambah Judul Offline</a>
            <a href="?p=Judul&sts=terima" class="btn btn-info" data-toggle="tooltip" title="Judul Sudah Diterima"> <i class="fa fa-eye"></i> Diterima</a>
            <a href="?p=Judul&sts=tolak" class="btn btn-info" data-toggle="tooltip" title="Judul Sudah Ditolak"> <i class="fa fa-eye"></i> Ditolak</a>
            <a href="?p=Judul&x=JudulProdi&prodi=sk" class="btn btn-info" data-toggle="tooltip" title="Judul Sistem Komputer"> <i class="fa fa-gear"></i> Sistem Komputer</a>
            <a href="?p=Judul&x=JudulProdi&prodi=si" class="btn btn-info" data-toggle="tooltip" title="Judul Sistem Informasi"> <i class="fa fa-laptop"></i> Sistem Informasi</a>
        </h2>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title"> <strong> <i class="fa fa-file"></i> Semua Judul Skripsi</strong></h3>
            </div>
          <div class="card-body">
            <form method="get">
                <input type="hidden" name="p" value="Judul">
                <input type="hidden" name="sts" value="<?= $sts ;?>">
              <div class="form-row">
                <div class="col-7">
                    <input type="text" name="key" value="<?= $key ;?>" class="form-control" placeholder="Cari NIM atau Judul Skripsi">
              </div>
              <div class="col">
                  <select class="form-control" id="thn" name="thn">
                          <option value="">Tahun Akademik</option>
                          <?php
                          foreach ($data['ta'] as $row) {
                              $tahun == $row['kode'] ? $s='selected' : $s='';
                              echo "<option value='".$row['kode']."' $s>$row[kode]</option>";
                          }
                          ?>
                      </select>
              </div>
              <div class="col">
                <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> <b>Cari</b></button>
                <a href="?p=Judul" class="btn btn-danger"><i class="fa fa-refresh"></i> <b>Semua</b></a>
              </div>
          </div>
      </form>
      <br/>
      <div class="table-responsive">
        <table class="table table-bordered table-sm table-hover table-striped" border="0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIM</th>
                    <th>Prodi</th>
                    <th>Judul</th>
                    <th>Bahasa</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = $data['no'];

                for ($i = 0; $i < count($data['judul']); $i++) {
                    ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td>
                            <a href="?p=Judul&x=Detail&id=<?= $data['judul'][$i]['id'] ?>" class="btn btn-info btn-sm" data-toggle="tooltip" title="Lihat Selengkapnya"> <?= $data['judul'][$i]['NIM'] ?> </a>
                        </td>
                        <td><?= $data['judul'][$i]['prodi'] ?></td>
                        <td><?= $data['judul'][$i]['judul'] ?></td>
                        <td><?= $data['judul'][$i]['bahasa'] ?></td>
                        <td class="text-bold"><?= $data['judul'][$i]['status'] ?></td>
                        <td>
                            <a href="?p=Judul&x=Ubah&id=<?= $data['judul'][$i]['id'] ?>" class="btn btn-outline-success btn-sm" data-toggle="tooltip" title="Edit Data"> <i class="fa fa-edit" aria-hidden></i> </a>
                            <a href="?p=Judul&x=Hapus&id=<?= $data['judul'][$i]['id'] ?>" class="btn btn-outline-danger btn-sm" data-toggle="tooltip" title="Hapus data" onclick="return confirm('Yakin akan dihapus')"> <i class="fa fa-remove" aria-hidden></i> </a>
                        </td>
                    </tr>
                    <?php $no++;
                } ?>
                <tr>
                    <td colspan="7" align="left">Jumlah : <?= $data['jumlah'];?></td>
                </tr>
            </tbody>
        </table>
        <ul class="pagination">       
            <!-- LINK FIRST AND PREV -->        
            <?php if($data['page'] == 1){
         // Jika page adalah page ke 1, maka disable link PREV        
              ?>          
              <li class="page-item disabled"><a href="#" class="page-link">First</a> </li>          
              <li class="page-item disabled"><a href="#" class="page-link">&laquo;</a> </li>        
              <?php }else{ 
          // Jika page bukan page ke 1          
                  $link_prev = ($data['page'] > 1)? $data['page'] - 1 : 1;?>          
                  <li class="page-item"><a href="?p=Judul<?= $link;?>&page=1" class="page-link">First</a> </li>          
                  <li class="page-item"><a href="?p=Judul<?= $link;?>&page=<?php echo $link_prev; ?>" class="page-link">&laquo;</a> </li>
                  <?php
              }

      // Hitung jumlah halamannya
              $jumlah_number = 5; 
      // Tentukan jumlah link number sebelum dan sesudah page yang aktif
              $start_number = ($data['page'] > $jumlah_number)? $data['page'] - $jumlah_number : 1; 
      // Untuk awal link number
              $end_number = ($data['page'] < ($data['jumlah_page'] - $jumlah_number)) ? $data['page'] + $jumlah_number : $data['jumlah_page'];

              for($i = $start_number; $i <= $end_number; $i++){
                $link_active = ($data['page'] == $i) ? ' active ' : ''; ?>
                <li class="page-item <?php echo $link_active; ?>"><a href="?p=Judul<?= $link;?>&page=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a></li>        
                <?php 
            }
            ?>


            <!-- LINK NEXT AND LAST -->        
            <?php        
      // Jika page sama dengan jumlah page, maka disable link NEXT nya
      // Artinya page tersebut adalah page terakhir
            if($data['page'] == $data['jumlah_page']){ 
      // Jika page terakhir ?>
      <li class="page-item disabled"><a href="#" class="page-link">&raquo;</a></li>
      <li class="page-item disabled"><a href="#" class="page-link">Last</a></li>
      <?php 
  }else{ 
    // Jika Bukan page terakhir
    $link_next = ($data['page'] < $data['jumlah_page'])? $data['page'] + 1 : $data['jumlah_page'];?>
    <li class="page-item"><a href="?p=Judul<?= $link;?>&page=<?php echo $link_next; ?>" class="page-link">&raquo;</a></li>
    <li class="page-item"><a href="?p=Judul<?= $link;?>&page=<?php echo $data['jumlah_page']; ?>" class="page-link">Last</a></li>
    <?php } 
    ?>
</ul>
</div>
</div>
</div>

</div>
</div>