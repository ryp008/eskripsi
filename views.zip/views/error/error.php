<div class="row">
    <div class="col-md-12 col-xs-12">
        <div class="alert alert-error">
            <strong> <span class="fa fa-remove"></span> Warning !!!</strong> Page Not Found, Try-Again...
        </div>
    </div>
</div>