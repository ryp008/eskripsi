<?php 
$cari = filter_input(INPUT_GET, 'key');
$prodi = filter_input(INPUT_GET, 'prodi');
if(empty($prodi)){
    $prd= 'semua';
}else{
    $prd = $prodi;
}

?>
<div class="row">
    <div class="col-md-12 col-xs-12">
        <h2>
            <a href="?p=Mahasiswa&x=Tambah" class="btn btn-outline-success"><strong> <i class="fa fa-user-plus"></i> Tambah Mahasisiswa</strong></a>
            <a href="" class="btn btn-outline-info"><strong> <i class="fa fa-user-plus"></i> Import Data Excel </strong></a>
        </h2>

        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?= $data['sub_title'];?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">  
                        <form action="" method="get">
                            <input type="hidden" name="p" value="Mahasiswa">
                            <div class="row">
                            <div class="col-sm-12 col-md-2">
                               Program Studi
                            </div>
                            <div class="col-sm-12 col-md-4">
                                <select name="prodi"  class="form-control">
                                    <option value="semua">Semua</option>
                                    <?php 
                                    foreach ($data['prodi'] as $value) {
                                        $value['Kode'] == $prd ? $s='selected' : $s='';
                                        echo "<option value='".$value['Kode']."' $s >".$value['Prodi']."</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-2">
                               NIM/Nama
                            </div>
                            <div class="col-sm-12 col-md-4">
                                <input type="text" name="key" class="form-control" placeholder="Cari dengan NIM/Nama">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-6 offset-md-2">
                                <button type="submit" class="btn btn-danger btn-flat"><span><i class="fa fa-refresh"></i></span> Refresh</button>
                                <a href="?p=Mahasiswa" class="btn btn-info btn-flat"><span><i class="fa fa-users"></i></span> Semua</a>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
                <br/>
                <br/>
                <table class="table table-bordered table-striped table-sm" style="font-size: 11pt">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Prodi</th>
                            <th>Email</th>
                            <th width="100">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = $data['no'];
                        foreach ($data['mhsw'] as $key) {
                            ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td><?= $key['NIM'] ?></td>
                                <td><?= $key['Name'] ?></td>
                                <td><?= $key['Prodi'] ?></td>
                                <td><?= $key['Email'] ?></td>
                                <td align="center">
                                    <a href="?p=Mahasiswa&x=Detail&id=<?= $key['ID'] ?>" class="text-success"> <i class="fa fa-eye" aria-hidden></i> </a>
                                    <a href="?p=Mahasiswa&x=Ubah&id=<?= $key['ID'] ?>" class="text-primary"> <i class="fa fa-edit" aria-hidden></i> </a>
                                    <a href="?p=Mahasiswa&x=Hapus&id=<?= $key['ID'] ?>" onclick="return confirm('Yakin akan menghapus mahasiswa ini?')" class="text-danger"> <i class="fa fa-remove" aria-hidden></i> </a>
                                </td>
                            </tr>

                            <?php
                            $no++;
                        }
                        ?>
                        <tr>
                            <td colspan="6" align="left">
                                <b>Jumlah : <?= $data['jumlah'];?></b>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <ul class="pagination">       
        <!-- LINK FIRST AND PREV -->        
        <?php if($data['page'] == 1){
         // Jika page adalah page ke 1, maka disable link PREV        
          ?>          
          <li class="page-item disabled"><a href="#" class="page-link">First</a> </li>          
          <li class="page-item disabled"><a href="#" class="page-link">&laquo;</a> </li>        
          <?php }else{ 
          // Jika page bukan page ke 1          
          $link_prev = ($data['page'] > 1)? $data['page'] - 1 : 1;?>          
          <li class="page-item"><a href="?p=Mahasiswa&prodi=<?= $prd ;?>&key=<?= $cari ;?>&page=1" class="page-link">First</a> </li>          
          <li class="page-item"><a href="?p=Mahasiswa&prodi=<?= $prd ;?>&key=<?= $cari ;?>&page=<?php echo $link_prev; ?>" class="page-link">&laquo;</a> </li>
        <?php
      }

      // Hitung jumlah halamannya
      $jumlah_number = 5; 
      // Tentukan jumlah link number sebelum dan sesudah page yang aktif
      $start_number = ($data['page'] > $jumlah_number)? $data['page'] - $jumlah_number : 1; 
      // Untuk awal link number
      $end_number = ($data['page'] < ($data['jumlah_page'] - $jumlah_number)) ? $data['page'] + $jumlah_number : $data['jumlah_page'];

      for($i = $start_number; $i <= $end_number; $i++){
        $link_active = ($data['page'] == $i) ? ' active ' : ''; ?>
        <li class="page-item <?php echo $link_active; ?>"><a href="?p=Mahasiswa&prodi=<?= $prd ;?>&key=<?= $cari ;?>&page=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a></li>        
        <?php 
      }
        ?>


      <!-- LINK NEXT AND LAST -->        
      <?php        
      // Jika page sama dengan jumlah page, maka disable link NEXT nya
      // Artinya page tersebut adalah page terakhir
      if($data['page'] == $data['jumlah_page']){ 
      // Jika page terakhir ?>
      <li class="page-item disabled"><a href="#" class="page-link">&raquo;</a></li>
      <li class="page-item disabled"><a href="#" class="page-link">Last</a></li>
      <?php 
    }else{ 
    // Jika Bukan page terakhir
    $link_next = ($data['page'] < $data['jumlah_page'])? $data['page'] + 1 : $data['jumlah_page'];?>
    <li class="page-item"><a href="?p=Mahasiswa&prodi=<?= $prd ;?>&key=<?= $cari ;?>&page=<?php echo $link_next; ?>" class="page-link">&raquo;</a></li>
    <li class="page-item"><a href="?p=Mahasiswa&prodi=<?= $prd ;?>&key=<?= $cari ;?>&page=<?php echo $data['jumlah_page']; ?>" class="page-link">Last</a></li>
    <?php } 
    ?>
        </ul>

            </div>
            <div class="card-footer">
                <i class="text-right">Sumber : Sistem Informasi Akademik</i>
            </div>
        </div>
    </div>
</div>
