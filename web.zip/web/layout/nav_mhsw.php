<li class="nav-item">
    <a href="?p=index" class="nav-link">
        <i class="nav-icon fa fa-dashboard text-danger"></i>
        <p>
            Dashboard
        </p>
    </a>
</li>
<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-book text-danger"></i>
        <p>
            Judul Skripsi
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Judul&x=PengajuanJudul" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Pengajuan Judul</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Judul&x=JudulSaya" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Judul Saya</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Judul&x=JudulProdi&prodi=si" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Semua Judul</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Judul&x=JudulProdi&prodi=si&sts=proses" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Judul Diproses</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Judul&x=JudulProdi&prodi=si&sts=terima" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Judul Diterima</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Judul&x=JudulProdi&prodi=si&sts=tolak" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Judul Ditolak</p>
            </a>
        </li>
    </ul>
</li>
<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-user-circle text-danger"></i>
        <p>
            Pembimbing Skirpsi
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Pembimbing&x=PembimbingMhsw" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Data Bimbingan</p>
            </a>
        </li>
    </ul>
</li>
<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-television text-danger"></i>
        <p>
            Seminar dan Sidang
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Seminar&x=SeminarProposalMhsw" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Seminar Porposal</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Seminar&x=SeminarHasilMhsw" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Seminar Hasil</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Sidang&x=SidangMhsw" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Sidang</p>
            </a>
        </li>
    </ul>
</li>  
<li class="nav-item">
    <a href="?p=Surat" class="nav-link">
        <i class="nav-icon fa fa-envelope-open text-danger"></i>
        <p>
            Surat-Surat
        </p>
    </a>
</li>

<li class="nav-item">
    <a href="?p=User&x=ProfilMhsw" class="nav-link">
        <i class="nav-icon fa fa-gears text-danger"></i>
        <p>
            Edit Profil
        </p>
    </a>
</li>