<?php Session::start();?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Thesis Applications | STMIK Royal Kisaran</title>
      	<link href="../vendor/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
      	<link href="../vendor/AdminLTE-2.4.3/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css"/>
      	<link href="../vendor/AdminLTE-2.4.3/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css"/>
      	<link href="assets/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css"/>
      	<link href="layout/main.css" rel="stylesheet" type="text/css"/>
      	<link href="../vendor/fontawesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
      	<link rel="shortcut icon" href="images/eplanning.jpg" type="image/x-icon"/>

    </head>
    <body>
	<!-- Fixed navbar -->
