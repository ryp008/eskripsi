<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <div class="row">
      <div class="col-sm-12 col-md-6">
        <table class="table table-sm">
          <tr>
            <th>NIK</th>
             <td>:</td>
            <td><?= $data['staff'][0]['NIK'] ;?></td>
          </tr>
          <tr>
            <th>Nama</th>
            <td>:</td>
            <td><?= $data['staff'][0]['Nama'] ;?></td>
          </tr>
           <tr>
            <th>Program Studi</th>
            <td>:</td>
            <td><?= $data['staff'][0]['Prodi'] ;?></td>
          </tr>
           <tr>
            <th>Bagian</th>
            <td>:</td>
            <td><?= $data['staff'][0]['Bagian'] ;?></td>
          </tr>
          <tr>
            <th>Jenis Kelamin</th>
            <td>:</td>
            <td><?= $data['staff'][0]['JenisKelamin'] == 'L' ? 'Laki-laki' : 'Perempuan' ;?></td>
          </tr>      
        </table>
      </div>
      <div class="col-sm-12 col-md-6">
        <table class="table table-sm">
          <tr>
            <th>Tanggal Lahir</th>
            <td>:</td>
            <td><?= $data['staff'][0]['TglLahir'] ;?></td>
          </tr>
          <tr>
            <th>Tempat Lahir</th>
            <td>:</td>
            <td><?= $data['staff'][0]['TempatLahir'] ;?></td>
          </tr>    
          <tr>
            <th>Alamat</th>
            <td>:</td>
            <td><?= $data['staff'][0]['Alamat'] ;?></td>
          </tr>
          <tr>
            <th>No. Telepon</th>
            <td>:</td>
            <td><?= $data['staff'][0]['Phone'] ;?></td>
          </tr>
          <tr>
            <td colspan="3" align="center">
              <?php 
              if($sess->get('level')){?>
                <a href="?p=Staff&x=Edit&id=<?= $data['staff'][0]['IDStaff'];?>" class="btn btn-info btn-flat">Edit</a>
                <a href="?p=Staff&x=Hapus&id=<?= $data['staff'][0]['IDStaff'];?>" class="btn btn-danger btn-flat" onclick="return confirm('Yakin akan menghapus Staff ini?')">Hapus</a>
                <?php } ?>
              <a href="?p=Staff" class="btn btn-dark btn-flat">Kembali</a>
            </td>
          </tr>
        </table>
      </div>
    </div>
  </div>
</div>