<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
    <table class="table">
      <tr>
        <td>NIK</td>
        <td>: <?=$data['row'][0]['nik']?></td>
      </tr>
      <tr>
        <td>Nama</td>
        <td>: <?=$data['row'][0]['nama']?></td>
      </tr>
      <tr>
        <td>Bagian</td>
        <td>: <?=$data['row'][0]['bagian']?></td>
      </tr>
    </table>
    <a href="?p=Biro&x=Update&id=<?= $data['row'][0]['id'] ?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> Update</a>
    <a href="?p=Biro&x=Hapus&id=<?= $data['row'][0]['id'] ?>" class="btn btn-outline-danger btn-sm"> <i class="fa fa-remove" aria-hidden></i> Remove </a>
    <a href="?p=Biro" class="btn btn-warning btn-sm"> <i class="fa fa-history" aria-hidden></i> Kembali </a>
  </div>
</div>

