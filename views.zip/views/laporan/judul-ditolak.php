<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <form class="" method="get" action="">
      <input type="hidden" name="p" value="Laporan">
      <input type="hidden" name="x" value="JudulDitolak">
      <div class="row">
       <label class="col-sm-12 col-md-2 text-right">Tahun</label>
       <div class="col-sm-12 col-md-4">
        <div class="input-group input-group-sm">
          <select name="thn" class="form-control" required="">
           <option value="semua">Semua</option>
           <?php
           foreach ($data['ta'] as $row) {
            $tahun == $row['kode'] ? $s='selected' : $s='';
            echo "<option value='".$row['kode']."' $s>$row[kode]</option>";
          }
          ?>
        </select>
        <span class="input-group-append">
          <button type="submit" name="go" value="refresh" class="btn btn-info btn-flat">Refresh</button>
        </span>
      </div>
      </div>
    </div>
  </form>
  <br/>
  <?php 
  if(isset($_GET['go'])){
      if(!empty($data['laporan'])){ ?>
        <a href="" onclick="cetak_slip('?p=Laporan&x=CetakJudulDitolak&thn=<?= filter_input(INPUT_GET, 'thn'); ?>','Cetak Judul Mahasiswa Diterima','width=800,height=600,scrollbars=yes')" class="btn btn-danger" data-toggle="tooltip" title="Cetak Laporan Judul"><i class="fa fa-print"></i> Cetak Laporan </a>
        <br/>
        <br/>
        <table class="table table-bordered table-sm" style="font-size: 10pt">
          <thead>
            <tr>
              <th>No.</th>
              <th>NIM</th>
              <th>Nama</th>
              <th>Judul</th>
              <th>Bahasa</th>
              <th>Objek</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no=0;

            foreach ($data['laporan'] as $key) {?>
              <tr>
                <td><?= ++$no ;?></td>
                <td><?= $key['NIM'];?></td>
                <td><?= $key['Name'];?></td>
                <td><?= $key['judul'];?></td>
                <td><?= $key['bahasa'];?></td>
                <td><?= $key['objek'];?></td>
                <td><?= $key['status'];?></td>
              </tr>              
            <?php } ?>
          </tbody>
        </table>
<?php
      }else{ ?>
<div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
             Data tidak ditemukan.
            </div>
      <?php }
  } ?>
</div>
</div>
