<li class="nav-item">
    <a href="?p=index" class="nav-link">
        <i class="nav-icon fa fa-dashboard"></i>
        <p>
            Dashboard
        </p>
    </a>
</li>
<!-- data dosen -->
<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa fa-briefcase text-danger"></i>
        <p>
            Master Data
            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="?p=Mahasiswa" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Mahasiswa</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Dosen" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Dosen</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=ProgramStudi" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Program Studi</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="?p=Tahun" class="nav-link">
                <i class="fa fa-circle-o nav-icon"></i>
                <p>Tahun Skripsi</p>
            </a>
        </li>
                                       <!-- <li class="nav-item">
                                            <a href="?p=Adhock" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Tim Ad-Hock</p>
                                            </a>
                                        </li>
                                    -->
                                    <li class="nav-item">
                                        <a href="?p=Timseleksi" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Tim Seleksi Judul</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Pejabat" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Pejabat</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Biro" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Biro Akademik</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Staff" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Staff Program Studi</p>
                                        </a>
                                    </li>
                                        <!--<li class="nav-item">
                                            <a href="?p=ProgramStudi" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>User Skripsi</p>
                                            </a>
                                        </li>
                                    -->
                                    <li class="nav-item">
                                        <a href="?p=Bahasa" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Bahasa Pemrograman</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- end data dosen -->
                            <!-- data Judul -->
                            <li class="nav-item">
                                <a href="?p=Judul" class="nav-link">
                                    <i class="nav-icon fa fa-book text-danger"></i>
                                    <p>
                                        Semua Judul
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-th text-info"></i>
                                    <p>
                                        Judul Skripsi SI
                                        <i class="right fa fa-angle-left"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=si" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Semua Judul</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=si&thn=&sts=proses" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Judul Diproses</p>
                                        </a>
                                    </li>
                                        <!--
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=Pengajuan" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Pengajuan Judul</p>
                                            </a>
                                        </li>
                                    -->
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=si&thn=&sts=terima" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Judul Diterima</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=si&thn=&sts=tolak" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Judul Ditolak</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=si&thn=&sts=tolak" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Input Judul Offline</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-th text-info"></i>
                                    <p>
                                        Judul Skripsi SK
                                        <i class="right fa fa-angle-left"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=sk" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Semua Judul</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=sk&thn=&sts=proses" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Judul Diproses</p>
                                        </a>
                                    </li>
                                        <!--
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=Pengajuan" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Pengajuan Judul</p>
                                            </a>
                                        </li>
                                    -->
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=sk&thn=&sts=terima" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Judul Diterima</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=JudulProdi&prodi=sk&thn=&sts=tolak" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Judul Ditolak</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=Ditolak" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Input Judul Offline</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- end data judul -->

                            <!-- data mahasiswa -->
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-user-circle text-warning"></i>
                                    <p>
                                        Mahasiswa
                                        <i class="right fa fa-angle-left"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="?p=Mahasiswa&x=mahasiswaaktif" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Mahasiswa Aktif</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Judul&x=Pengajuan" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Mahasiswa Transfer</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Mahasiswa&x=aktifkanmhsw" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Aktifkan Mahasiwa</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- end data mahasiswa -->
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-pie-chart text-danger"></i>
                                    <p>
                                        Pembayaran
                                        <i class="right fa fa-angle-left"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="?p=Pembayaran&x=bayar" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Form Pembayaran</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Pembayaran&x=allpembayaran" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Semua Pembayaran</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Pembayaran&x=pembayaranlunas" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Pembayaran Lunas</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- data Dosen -->
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-user-circle text-success"></i>
                                    <p>
                                        Pembimbing
                                        <i class="right fa fa-angle-left"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="?p=Pembimbing" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>List Pembimbing</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Pembimbing&x=SetPembimbing" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Set Pembimbing</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-pie-chart text-danger"></i>
                                    <p>
                                        Seminar dan Sidang
                                        <i class="right fa fa-angle-left"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="?p=Seminar&x=SeminarProposal" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Seminar Proposal</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Seminar&x=SeminarHasil" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Seminar Hasil</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Sidang" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Sidang Meja Hijau</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- end data dosen -->
                            <!-- data prodi -->
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-user-circle text-info"></i>
                                    <p>
                                        Laporan
                                        <i class="right fa fa-angle-left"></i>
                                    </p>
                                </a>
                               <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=Semua" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Semua Judul</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=JudulDiterima" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diterima</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=JudulDitolak" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Ditolak</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=DosenPembimbing" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Dosen Pembimbing</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=LaporanPembayaran" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Laporan Pembayaran</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=LaporanSempro" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Laporan Seminar Proposal</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=LaporanSemha" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Laporan Seminar Hasil</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Laporan&x=LaporanSidang" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Laporan Sidang</p>
                                            </a>
                                        </li>
                                </ul>
                            </li>
                            <!-- end data prodi -->


                            <!-- menu file skripsi  -->
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-table"></i>
                                    <p>
                                        Arsip File Skripsi
                                        <i class="fa fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="?p=Arsip" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Arsip Laporan Skripsi</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=Arsip&x=Apps" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>App atau Alat Skripsi</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fa fa-pie-chart text-danger"></i>
                                    <p>
                                        User Skripsi
                                        <i class="right fa fa-angle-left"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="?p=User&x=Admin" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Admin</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=User&x=Prodi" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Program Studi</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=User&x=Biro" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Biro Akademik</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=User&x=Dosen" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Dosen</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="?p=User&x=Mhsw" class="nav-link">
                                            <i class="fa fa-circle-o nav-icon"></i>
                                            <p>Mahasiswa</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- end file skripsi -->
<?php /*
                                <li class="nav-header">KONFIGURASI</li>
                                <!-- menu conf 1  -->
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-cogs "></i>
                                        <p>
                                            Systems
                                            <i class="fa fa-angle-left right"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="pages/tables/simple.html" class="nav-link">
                                                <i class="fa fa-database nav-icon"></i>
                                                <p>Simple Tables</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="pages/tables/data.html" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Data Tables</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <!-- menu conf 2  -->
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-database"></i>
                                        <p>
                                            Database
                                            <i class="fa fa-angle-left right"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="pages/tables/simple.html" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Simple Tables</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="pages/tables/data.html" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Data Tables</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>

                                <!-- menu conf 2  -->
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-user-md"></i>
                                        <p>
                                            Hak Akses User
                                            <i class="fa fa-angle-left right"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="pages/tables/simple.html" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Simple Tables</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="pages/tables/data.html" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Data Tables</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                */ ?>