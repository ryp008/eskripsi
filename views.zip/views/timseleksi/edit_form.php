<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <form action="?p=Timseleksi&x=Edit" method="post">
      <input type="hidden" name="idtim" value="<?= $data['row'][0]['id'];?>">
      <div class="form-group">
        <label>Dosen</label>
        <select name="IDDosen" class="form-control col-4" required="" readonly disabled="">
          <option value="">-Pilih Dosen-</option>
          <?php
          foreach ($data['dosen'] as $row) {
            $data['row'][0]['iddosen'] == $row['ID'] ? $s='selected' : $s='';
            echo "<option value='".$row['ID']."' $s>$row[NamaDosen]</option>";
          }
          ?>
        </select>
      </div>
      <div class="form-group">
        <label>Program Studi</label>
        <select name="Prodi" class="form-control col-4" required="">
          <option value="">Pilih</option>
          <?php 
          $optionprodi = array('SI' => 'Sistem Informasi', 'SK'=>'Sistem Komputer');
          foreach ($optionprodi as $value =>$key) {
            $data['row'][0]['prodi'] == $value ? $s='selected' : $s='';
            echo "<option value='".$value."' $s>$key</option>";
          }
          ?>
        </select>
      </div>
      <div class="form-group">
        <input type="submit" name="simpan" value="Simpan" class="btn btn-info btn-flat">
        <a href="?p=Timseleksi" class="btn btn-dark btn-flat">Batal</a>
      </div>
    </form>
  </div>
</div>