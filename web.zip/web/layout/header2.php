<?php 
//Session::start() ;
$sess = new Session;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> <?=Ethesis::getTitle()?> | Skripsi Online STMIK Royal</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="shortcut icon" href="./images/stmik1.png">
    <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="../vendor/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../vendor/AdminLTE-3/dist/css/adminlte.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/iCheck/flat/blue.css">
    <!-- Morris chart -->
    <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/morris/morris.css">
    <!-- jvectormap -->
    <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/datepicker/datepicker3.css">
    <!-- datatable -->
    <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/datatables/dataTables.bootstrap4.css">

    <!-- Daterange picker -->
    <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
        <link rel="stylesheet" type="text/css" href="../vendor/Parsley.js-2.8.1/src/parsley.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <script src="../vendor/tinymce/tinymce.min.js"></script>
    
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="?p=Index" class="nav-link">Home</a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="?p=Index&x=Contact" class="nav-link">Contact</a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="?p=Tentang" class="nav-link">About</a>
                </li>
            </ul>

            <!-- SEARCH FORM -->
            <form class="form-inline ml-3">
                <div class="input-group input-group-sm">
                    <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
                    <div class="input-group-append">
                        <button class="btn btn-navbar" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>

            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <!-- Messages Dropdown Menu -->
                <?php 
                if(Session::get('islogin')){ ?>
                    <?php /*
                    <li class="nav-item dropdown">
                        <a class="nav-link" data-toggle="dropdown" href="#">
                            <i class="fa fa-comments-o"></i>
                            <span class="badge badge-danger navbar-badge">3</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            <a href="#" class="dropdown-item">
                                <!-- Message Start -->

                                <div class="media">
                                    <img src="./images/SOP.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                            Brad Diesel
                                            <span class="float-right text-sm text-danger"><i class="fa fa-star"></i></span>
                                        </h3>
                                        <p class="text-sm">Call me whenever you can...</p>
                                        <p class="text-sm text-muted"><i class="fa fa-clock-o mr-1"></i> 4 Hours Ago</p>
                                    </div>
                                </div>
                                <!-- Message End -->
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <!-- Message Start -->
                                <div class="media">
                                    <img src="./images/SOP.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                            John Pierce
                                            <span class="float-right text-sm text-muted"><i class="fa fa-star"></i></span>
                                        </h3>
                                        <p class="text-sm">I got your message bro</p>
                                        <p class="text-sm text-muted"><i class="fa fa-clock-o mr-1"></i> 4 Hours Ago</p>
                                    </div>
                                </div>
                                <!-- Message End -->
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <!-- Message Start -->
                                <div class="media">
                                    <img src="./images/SOP.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                            Nora Silvester
                                            <span class="float-right text-sm text-warning"><i class="fa fa-star"></i></span>
                                        </h3>
                                        <p class="text-sm">The subject goes here</p>
                                        <p class="text-sm text-muted"><i class="fa fa-clock-o mr-1"></i> 4 Hours Ago</p>
                                    </div>
                                </div>
                                <!-- Message End -->
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
                        </div>
                    </li>
                
                    <!-- Notifications Dropdown Menu -->
                    <li class="nav-item dropdown">
                        <a class="nav-link" data-toggle="dropdown" href="#">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge badge-warning navbar-badge">15</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            <span class="dropdown-item dropdown-header">15 Notifications</span>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <i class="fa fa-envelope mr-2"></i> 4 new messages
                                <span class="float-right text-muted text-sm">3 mins</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <i class="fa fa-users mr-2"></i> 8 friend requests
                                <span class="float-right text-muted text-sm">12 hours</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <i class="fa fa-file mr-2"></i> 3 new reports
                                <span class="float-right text-muted text-sm">2 days</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
                        </div>
                    </li>
                    */ ?>
                        <li class="nav-item d-none d-sm-inline-block" ><a href="#" class="nav-link disabled"><strong>Skripsi <u>Online</u></strong></a></li>
                        <li class="nav-item"> 
                        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i class="fa fa-th-large"></i></a>
                        </li>
                       
                        <li class="nav-item d-none d-sm-inline-block"> <a href="?p=User&x=Logout" class="nav-link">Logout <i class="fa fa-sign-out" aria-hidden></i> </a> </li>
                        <?php }else{?>
                            <li class="nav-item d-none d-sm-inline-block"> <a href="?p=User" class="nav-link">Login <i class="fa fa-sign-in" aria-hidden></i> </a> </li>
                            <?php } ?>
                        </ul>

                    </nav>
                    <!-- /.navbar -->
                    <!-- Main Sidebar Container -->
                    <aside class="main-sidebar sidebar-dark-primary elevation-4">
                        <!-- Brand Logo -->
                        <a href="?p=index" class="brand-link">
                            <img src="./images/stmik1.png" alt="Logo" class="brand-image img-circle elevation-3"
                            style="opacity: .8">
                            <span class="brand-text font-weight-light"><strong>STMIK</strong>Royal</span>
                        </a>

                        <!-- Sidebar -->
                        <div class="sidebar">
                            <!-- Sidebar user panel (optional) -->

                            <?php 

                            if(Session::get('id_user')){
                                ?>
                                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                                    
                                    <div class="image">
                                        <img src="./images/user1.png" class="img-rounded elevation-2" alt="User Image">
                                    </div>
                                
                                <div class="info">
                                    <label class="d-block" style="color:white;"><?= Session::get('name');?><?php if(Session::get('level')): echo "<br>Administrator"; endif; ?></label>
                                    <a href="?p=User&x=Logout" class="d-block"> <i class="fa fa-sign-out" aria-hidden></i> Logout</a>
                                </div>
                            </div>
                            <?php }?>
                            <!-- Sidebar Menu -->
                            <nav class="mt-2">
                                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                            <!-- Add icons to the links using the .nav-icon class
                             with font-awesome or any other icon font library -->

                             <?php 
                        //menu jika Sudah login

                             if(Session::get('id_user')){
                                if(Session::get('level') == 1){
                                  include 'nav_admin.php';
                            }elseif(Session::get('level') == 2){ 
                                  include 'nav_prodi.php';
                            }elseif(Session::get('level') == 3){ 
                                  include 'nav_biro.php';
                            }elseif(Session::get('level') == 4){ 
                                  include 'nav_dosen.php';
                            }else{ 
                                  include 'nav_mhsw.php';
                            }
                        }else{ ?>
                            <li class="nav-item">
                                <a href="?p=index" class="nav-link">
                                    <i class="nav-icon fa fa-dashboard"></i>
                                    <p>
                                        Home
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="?p=index" class="nav-link">
                                    <i class="nav-icon fa fa-dashboard"></i>
                                    <p>
                                        Judul Skripsi
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="?p=User" class="nav-link">
                                    <i class="nav-icon fa fa-sign-in"></i>
                                    <p>
                                        Login
                                    </p>
                                </a>
                            </li>

                            <!-- end conf 1 -->
                            <?php } ?>
                            <li class="nav-item">
                                <a href="?p=Statistik" class="nav-link">
                                    <i class="nav-icon fa fa-line-chart text-danger"></i>
                                    <p>
                                        Statistic Skripsi
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="?p=Tentang" class="nav-link">
                                    <i class="nav-icon fa fa-info-circle text-danger"></i>
                                    <p>
                                        Tentang Skripsi
                                    </p>
                                </a>
                            </li>
                            <li class="nav-header">DOKUMENTASI</li>
                            <li class="nav-item">
                                <a href="https://adminlte.io/docs" class="nav-link">
                                    <i class="nav-icon fa fa-file text-danger"></i>
                                    <p>Tutorial</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="https://adminlte.io/docs" class="nav-link">
                                    <i class="nav-icon fa fa-book text-info"></i>
                                    <p>Ebook</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="?p=Index&x=Bantuan" class="nav-link">
                                    <i class="nav-icon fa fa-question text-primary"></i>
                                    <p>Bantuan</p>
                                </a>
                            </li>
                            <li class="nav-header">Publikasi</li>
                            <li class="nav-item">
                                <a href="https://jurnal.stmikroyal.ac.id" target="_blank" class="nav-link">
                                    <i class="nav-icon fa fa-circle-o text-danger"></i>
                                    <p class="text">E-Jurnal Royal</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="https://scholar.google.com" target="_blank" class="nav-link">
                                    <i class="nav-icon fa fa-circle-o text-warning"></i>
                                    <p>Google Scholar</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="http://digilib.stmikroyal.ac.id" class="nav-link">
                                    <i class="nav-icon fa fa-circle-o text-info"></i>
                                    <p>Perpustakaan</p>
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <!-- /.sidebar-menu -->
                </div>
                <!-- /.sidebar -->
            </aside>
