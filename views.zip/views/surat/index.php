<div class="card">
        <div class="card-header">
          <h5 class="card-title"><?= $data['sub_title'];?></h5>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse">
              <i class="fa fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-widget="remove">
              <i class="fa fa-times"></i>
          </button>
      </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body p-0">
              <div class="mailbox-controls">
                <!-- Check all button -->
                <button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i>
                </button>
                <div class="btn-group">
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></button>
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-reply"></i></button>
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-share"></i></button>
                </div>
                <!-- /.btn-group -->
                <button type="button" class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>
                <div class="float-right">
                  <div class="btn-group">
                    <button type="button" class="btn btn-default btn-sm"><i class="fa fa-chevron-left"></i></button>
                    <button type="button" class="btn btn-default btn-sm"><i class="fa fa-chevron-right"></i></button>
                  </div>
                  <!-- /.btn-group -->
                </div>
                <!-- /.float-right -->
              </div>
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover table-striped">
                  <tbody>
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Surat Tugas Dosen Pembimbing
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakDoping', 'Cetak Surat Dosen Pembimbing', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                  <!--<tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Surat Tugas Dosen Pembimbing 2
                    </td>
                    <td class="mailbox-date"><a href="#" onclick="cetak_slip('?p=Surat&x=CetakDoping', 'Cetak Surat Dosen Pembimbing', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr> -->
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Bukti Kelayakan Judul Skripsi
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakKelayakanJudul', 'Cetak Bukti Kelayakan Judul Skripsi', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Surat Pemohonan Seminar Proposal
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakPermohonanSempro', 'Cetak Bukti Kelayakan Judul Skripsi', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Kartu Kehadiran Seminar Proposal
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakKehadiranSeminar&kd=1', 'Cetak Kehadiran Seminar Proposal', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a>
                  </tr>
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Undangan Seminar Proposal Untuk Dosen Pembimbing
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakUndanganSempro', 'Cetak Skripsi Mahasiswa', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                  <!--<tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Undangan Seminar Proposal Untuk Dosen Pembimbing 2
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakUndanganSempro', 'Cetak Skripsi Mahasiswa', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr> -->
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Surat Pemohonan Seminar Hasil
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakPermohonanSemha', 'Cetak Bukti Kelayakan Judul Skripsi', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Kartu Kehadiran Seminar Hasil
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakKehadiranSeminar&kd=2', 'Cetak Kehadiran Seminar Hasil', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Undangan Seminar Hasil Untuk Dosen Pembimbing
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakUndanganSemha', 'Cetak Skripsi Mahasiswa', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                  <!--<tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Undangan Seminar Hasil Untuk Dosen Pembimbing 2
                    </td>
                    <td class="mailbox-date"><a href="#" onclick="cetak_slip('?p=Surat&x=CetakUndanganSemha', 'Cetak Skripsi Mahasiswa', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>-->
                  <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Berkas Pendaftaran Seminar Hasil
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('view/reports/cetakpembimbing.html?kode=1', 'Cetak Skripsi Mahasiswa', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                   <tr>
                    <td><input type="checkbox"></td>
                    <td class="mailbox-star"><a href="#"><i class="fa fa-envelope text-warning"></i></a></td>
                    <td class="mailbox-name"><a href="read-mail.html"><?= $sess->get('name');?></a></td>
                    <td class="mailbox-subject">Surat Pemohonan Sidang
                    </td>
                    <td class="mailbox-date"> <a href="#" onclick="cetak_slip('?p=Surat&x=CetakPermohonanSidang', 'Cetak Surat Permohonan Sidang', 'width=720,height=800,scrollbars=yes')"><i class="fa fa-print"></i> <b>Cetak</b></a></td>
                  </tr>
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.card-body -->
            <div class="card-footer p-0">
              <div class="mailbox-controls">
                <!-- Check all button -->
                <button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i>
                </button>
                <div class="btn-group">
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></button>
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-reply"></i></button>
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-share"></i></button>
                </div>
                <!-- /.btn-group -->
                <button type="button" class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>
                <div class="float-right">
                  <div class="btn-group">
                    <button type="button" class="btn btn-default btn-sm"><i class="fa fa-chevron-left"></i></button>
                    <button type="button" class="btn btn-default btn-sm"><i class="fa fa-chevron-right"></i></button>
                  </div>
                  <!-- /.btn-group -->
                </div>
                <!-- /.float-right -->
              </div>
            </div>
</div>