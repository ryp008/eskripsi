<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
        <form method="post" action="?p=Dosen&x=SimpanEdit">
          <input type="hidden" name="ID" value="<?= $data['row'][0]['ID'] ;?>">
          <fieldset class="form-group">
            <label for="txtNIDN">NIDN</label>
            <input type="text" name="NIDN" class="form-control" value="<?= $data['row'][0]['NIDN'] ;?>" placeholder="NIDN" required>
            <small class="text-muted">Nomor Induk Dosen Nasional</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">NIK</label>
            <input type="text" class="form-control" name="NIK" placeholder="NIK" value="<?= $data['row'][0]['NIK'] ;?>" required>
            <small class="text-muted">Nomor Induk Kepegawaian</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Nama</label>
            <input type="text" class="form-control" name="Name" value="<?= $data['row'][0]['Name'] ;?>" placeholder="Nama" required>
            <small class="text-muted">Nama Lengkap</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="Gelar">Gelar</label>
            <input type="text" class="form-control" name="Gelar" value="<?= $data['row'][0]['Gelar'] ;?>" placeholder="Gelar" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Jenis Kelamin</label><br/>
            <input type="radio" name="Sex" value="L" <?php echo $data['row'][0]['Sex'] == 'L' ? 'checked' : '' ;?> >Laki laki<br/>
            <input type="radio" name="Sex" value="P" <?php echo $data['row'][0]['Sex'] == 'P' ? 'checked' : '' ;?> >Perempuan
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Tanggal Lahir</label>
            <input type="text" class="form-control" name="TglLahir" value="<?= $data['row'][0]['TglLahir'] ;?>" placeholder="YYYY-MM-DD" required>
            <small class="text-muted"></small>
          </fieldset>

<fieldset class="form-group">
            <label for="">Tempat Lahir</label>
            <input type="text" class="form-control" name="TempatLahir" value="<?= $data['row'][0]['TempatLahir'] ;?>" placeholder="Tempat Lahir" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="txtNamaLengkap">Alamat</label>
            <textarea name="Alamat" id="alamat" class="form-control" rows="8" cols="80" required><?= $data['row'][0]['Alamat1'] ;?></textarea>
            <small class="text-muted">Alamat lengkap mahasiswa</small>
          </fieldset>
          
          <fieldset class="form-group">
            <label for="">Email</label>
            <input type="email" class="form-control" name="Email" value="<?= $data['row'][0]['Email'] ;?>" placeholder="e-mail" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">No. Telepon</label>
            <input type="text" class="form-control" name="Phone" value="<?= $data['row'][0]['Phone'] ;?>" placeholder="Nomor Telepon" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Jenjang Pendidikan</label>
            <select class="form-control" name="Jenjang" required="">
              <option value="">-Pilih-</option>
              <?php 
              foreach ($data['jenjang'] as $value) {
                $data['row'][0]['JenjangDosen'] == $value['Kode'] ? $s='selected' : $s='';
                echo "<option value='".$value['Kode']."' $s> $value[Nama]</option>";
              }
              ?>
            </select>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Lulusan PT</label>
            <input type="text" class="form-control" name="LulusanPT" value="<?= $data['row'][0]['LulusanPT'] ;?>" placeholder="Lulusan Perguruan Tinggi" required>
            <small class="text-muted"></small>
          </fieldset>

          <button type="submit" name="simpan" class="btn btn-success"> <i class="fa fa-save" aria-hidden></i> Simpan </button>
          <a href="?p=Dosen" class="btn btn-danger"> <i class="fa fa-history

          " aria-hidden></i> Kembali</a>
        </form>
      </div>
    </div>
