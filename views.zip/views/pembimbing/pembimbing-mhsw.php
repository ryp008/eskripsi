<div class="card">
        <div class="card-header">
          <h5 class="card-title"><?= $data['sub_title'];?></h5>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse">
              <i class="fa fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-widget="remove">
              <i class="fa fa-times"></i>
          </button>
      </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <table class="table table-bordered table-sm table-hover table-striped" border="0">
      <thead>
        <tr>
          <th>No.</th>
          <th>Pembimbing 1</th>
          <th>Pembimbing 2</th>
          <th>Bimbingan s/d</th>
          <th>No. Surat</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $no=0;
        foreach ($data['pembimbing'] as $value) { ?>
          <tr>
            <td><?= ++$no; ?></td>
            <td><?= $value['Dosen1'];?></td>
            <td><?= $value['Dosen2'];?></td>
            <td><?= $value['Mbimbingan']."/".$value['Sbimbingan'];?></td>
            <td><?= $value['NoSurat'];?></td>
          </tr>
         <?php  
        }?>
      </tbody>
    </table>
  </div>
</div>